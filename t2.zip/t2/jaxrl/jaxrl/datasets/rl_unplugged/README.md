Run to preprocess the datasets:

```bash
python preprocess.py --task_name cartpole_swingup
python preprocess.py --task_name cheetah_run 
python preprocess.py --task_name finger_turn_hard 
python preprocess.py --task_name fish_swim 
python preprocess.py --task_name humanoid_run 
python preprocess.py --task_name manipulator_insert_ball
python preprocess.py --task_name manipulator_insert_peg
python preprocess.py --task_name walker_stand
python preprocess.py --task_name walker_walk
```

The datasets will be saved in the default d4rl folder.