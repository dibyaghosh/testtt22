"""
Based on
https://github.com/rail-berkeley/doodad/blob/master/testing/remote/test_azure_with_mounts.py

Instructions:
1) Set up testing/config.py (copy from config.py.example and fill in the fields)
2) Run this script
3) Look inside your AZ_CONTAINER and you should see results in test_azure_with_mounts/azure_script_output/output.out
"""
import os

import doodad
import doodad.wrappers.sweeper.hyper_sweep as hyper_sweep
from doodad.utils import TESTING_DIR

AZ_SUB_ID = os.environ['AZURE_SUBSCRIPTION_ID']
AZ_CLIENT_ID = os.environ['AZURE_CLIENT_ID']
AZ_TENANT_ID = os.environ['AZURE_TENANT_ID']
AZ_SECRET = os.environ['AZURE_CLIENT_SECRET']
AZ_CONTAINER = os.environ['AZURE_STORAGE_CONTAINER']
AZ_CONN_STR = os.environ['AZURE_STORAGE_CONNECTION_STRING']


def run():
    experiment_prefix = '20211203_sweep'

    launcher = doodad.AzureMode(
        azure_subscription_id=AZ_SUB_ID,
        azure_storage_connection_str=AZ_CONN_STR,
        azure_client_id=AZ_CLIENT_ID,
        azure_authentication_key=AZ_SECRET,
        azure_tenant_id=AZ_TENANT_ID,
        azure_storage_container=AZ_CONTAINER,
        log_path=f'jax-rl/{experiment_prefix}/',
        region='eastus2',
        instance_type='Standard_DS1_v2',
        tags={'user': 'dibya', 'experiment_name': experiment_prefix},
        overwrite_logs=True,
        # dry=True,
        # To run on GPU comment instance_type and uncomment lines below.
        # use_gpu=True,
        # gpu_model='nvidia-tesla-t4',
        # num_gpu=1
    )

    az_mount = doodad.MountAzure(
        'azure_script_output',
        mount_point='/output',
    )
    local_mount = doodad.MountLocal(local_dir=TESTING_DIR,
                                    mount_point='/data',
                                    output=False)
    code_mount1 = doodad.MountLocal(local_dir=os.path.abspath('/home/dibya/projects/jaxrl/'),
                                    mount_point='/code/jax-rl',
                                    pythonpath=True)
    mounts = [local_mount, az_mount, code_mount1]
    # doodad.run_command(
    #     command=
    #     f'python -u /code/jax-rl/examples/train.py --experiment_id={experiment_id!r} --env_name=HalfCheetah-v2 --max_steps=10000 --config=/code/jax-rl/examples/configs/sac_default.py  --save_dir=/output/',
    #     mode=launcher,
    #     mounts=mounts,
    #     verbose=True,
    #     docker_image="dibyaghosh/jaxrl:latest",
    # )
    params = {
            # 'max_steps':[10000, 50000, 100000],
            'n_ensemble': [10],
            'config.actor_variant': ['mean', 'classifier'],
            'config.independent': [True],
            # 'env_name': ['walker2d-medium-replay-v2'],
            'env_name': ['walker2d-random-v2', 'hopper-random-v2', 'halfcheetah-random-v2',],

    }
    default_params = {
            'config': '/code/jax-rl/examples/configs/sac_default.py',
            'exp_prefix': experiment_prefix,
            'exp_descriptor': "'{env_name}_ensemble_{n_ensemble}_{actor_variant}'",
            'save_dir': '/output/',
            'silent': True,
    }
    sweeper = hyper_sweep.Sweeper(params, default_params)
    for config in sweeper:
        print(config)
    hyper_sweep.run_sweep_doodad(
        os.path.abspath('/home/dibya/projects/jaxrl/examples/train_ensembles.py'),
        params=params,
        default_params=default_params,
        run_mode=launcher,
        mounts=mounts,
        docker_image="dibyaghosh/jaxrl:latest",
        verbose=True,
    )

if __name__ == '__main__':
    run()
