import os

import numpy as np
import tqdm
from absl import app, flags
from ml_collections import config_flags
from tensorboardX import SummaryWriter

from ensemble_jaxrl.agents.sacn.sac_learner import SACLearner
# from jaxrl.datasets import make_env_and_dataset
from jaxrl.datasets.d4rl_dataset import D4RLDataset
from jaxrl.datasets.dataset import split_into_trajectories

from jaxrl.utils import make_env

from jaxrl.evaluation import evaluate
from ensemble_jaxrl.wandb_utils import WandBLogger
import datetime


from typing import Optional

import gym
from gym.spaces import Box
from gym.wrappers import RescaleAction

from jaxrl import wrappers
from jaxrl.wrappers import VideoRecorder



FLAGS = flags.FLAGS

flags.DEFINE_string('env_name', 'halfcheetah-expert-v2', 'Environment name.')
flags.DEFINE_enum('dataset_name', 'd4rl', ['d4rl', 'awac', 'rl_unplugged'],
                  'Dataset name.')
flags.DEFINE_string('exp_prefix', 'test', 'Name of experiment')
flags.DEFINE_string('exp_descriptor', 'sac', 'Name of experiment')

flags.DEFINE_string('save_dir', '../../tmp/', 'Tensorboard logging dir.')
flags.DEFINE_integer('seed', 42, 'Random seed.')
flags.DEFINE_integer('eval_episodes', 10,
                     'Number of episodes used for evaluation.')
flags.DEFINE_integer('log_interval', 1000, 'Logging interval.')
flags.DEFINE_integer('eval_interval', 5000, 'Eval interval.')
flags.DEFINE_integer('save_interval', 100000, 'Eval interval.')

flags.DEFINE_integer('batch_size', 256, 'Mini batch size.')
flags.DEFINE_integer('max_steps', int(1e6), 'Number of training steps.')
flags.DEFINE_float(
    'percentile', 100.0,
    'Dataset percentile (see https://arxiv.org/abs/2106.01345).')
flags.DEFINE_float('percentage', 100.0,
                   'Pencentage of the dataset to use for training.')
flags.DEFINE_boolean('tqdm', True, 'Use tqdm progress bar.')
flags.DEFINE_boolean('save_video', False, 'Save videos during evaluation.')
config_flags.DEFINE_config_file(
    'config',
    'configs/msg_default.py',
    'File path to the training hyperparameter configuration.',
    lock_config=False)

def normalize(dataset):

    trajs = split_into_trajectories(dataset.observations, dataset.actions,
                                    dataset.rewards, dataset.masks,
                                    dataset.dones_float,
                                    dataset.next_observations)

    def compute_returns(traj):
        episode_return = 0
        for _, _, rew, _, _, _ in traj:
            episode_return += rew

        return episode_return

    trajs.sort(key=compute_returns)

    dataset.rewards /= compute_returns(trajs[-1]) - compute_returns(trajs[0])
    dataset.rewards *= 1000.0


def make_env_and_dataset(env_name: str,
                         seed: int):

    env = gym.make(env_name)

    env = wrappers.EpisodeMonitor(env)
    env = wrappers.SinglePrecision(env)

    env.seed(seed)
    env.action_space.seed(seed)
    env.observation_space.seed(seed)

    dataset = D4RLDataset(env)

    if 'antmaze' in FLAGS.env_name:
        dataset.rewards = (dataset.rewards - 0.5) * 4 #1.0
        # See https://github.com/aviralkumar2907/CQL/blob/master/d4rl/examples/cql_antmaze_new.py#L22
        # but I found no difference between (x - 0.5) * 4 and x - 1.0
    # elif ('halfcheetah' in FLAGS.env_name or 'walker2d' in FLAGS.env_name
    #       or 'hopper' in FLAGS.env_name):
    #     normalize(dataset)

    return env, dataset

def main(_):

    FLAGS.seed = np.random.choice(1000000)
    FLAG_DICT = {k: getattr(FLAGS, k) for k in FLAGS}
    FLAG_DICT.update({k: FLAGS.config[k] for k in FLAGS.config})

    FLAGS.exp_descriptor = FLAGS.exp_descriptor.format(**FLAG_DICT)
    unique_identifier = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    exp_id = f'{FLAGS.exp_descriptor}_{unique_identifier}' #uuid.uuid4().hex
    FLAGS.save_dir = os.path.join(FLAGS.save_dir, FLAGS.exp_prefix, exp_id)
    os.makedirs(FLAGS.save_dir, exist_ok=True)



    video_save_folder = None if not FLAGS.save_video else os.path.join(
        FLAGS.save_dir, 'video', 'eval')

    env, dataset = make_env_and_dataset(FLAGS.env_name, FLAGS.seed)
    if FLAGS.percentage < 100.0:
        dataset.take_random(FLAGS.percentage)

    if FLAGS.percentile < 100.0:
        dataset.take_top(FLAGS.percentile)


    config = FLAGS.config
    wandb_logger = WandBLogger(dict(), dict(config), exp_prefix=FLAGS.exp_prefix, exp_descriptor=FLAGS.exp_descriptor, unique_identifier=unique_identifier)

    kwargs = dict(FLAGS.config)
    # kwargs['num_steps'] = FLAGS.max_steps
    kwargs.pop('algo')
    kwargs.pop('replay_buffer_size')
    agent = SACLearner(FLAGS.seed,
                      env.observation_space.sample()[np.newaxis],
                      env.action_space.sample()[np.newaxis], **kwargs)

    eval_returns = []
    for i in tqdm.tqdm(range(1, FLAGS.max_steps + 1),
                       smoothing=0.1,
                       disable=not FLAGS.tqdm):
        batch = dataset.sample(FLAGS.batch_size)

        update_info = agent.update(batch)

        if i % FLAGS.log_interval == 0:
            train_metrics = dict(iteration=i)
            for k, v in update_info.items():
                train_metrics[f'training/{k}'] = v
            wandb_logger.log(train_metrics, step=i)

        if i % FLAGS.eval_interval == 0:
            eval_stats = evaluate(agent, env, FLAGS.eval_episodes)

            eval_metrics = dict()
            for k, v in eval_stats.items():
                eval_metrics[f'evaluation/average_{k}s'] = v
            
            wandb_logger.log(eval_metrics, step=i)

        if i % FLAGS.save_interval == 0:
            state_dict =  agent.serialize()
            
            import gzip
            import pickle
            fname = os.path.join(FLAGS.save_dir, f'iter_{i}.gz')
            print(f'Saving to {fname}')
            with gzip.open(fname, "wb") as f:
                pickle.dump(state_dict, f)

if __name__ == '__main__':
    app.run(main)
