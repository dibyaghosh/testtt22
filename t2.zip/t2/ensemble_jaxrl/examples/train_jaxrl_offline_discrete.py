import os

import numpy as np
import tqdm
from absl import app, flags
from ml_collections import config_flags
from tensorboardX import SummaryWriter

# from jaxrl.agents import SACLearner
from ensemble_jaxrl.agents.ensemble_sql.sac_learner import SACLearner, evaluate

from jaxrl.datasets import make_env_and_dataset
from ensemble_jaxrl.contextual_dataset import DatasetWrapper, make_dictenv_and_dataset
# from jaxrl.evaluation import evaluate
from room_world import multiroom
from ensemble_jaxrl.wandb_utils import WandBLogger
import datetime
import room_world.multiroom2
FLAGS = flags.FLAGS

flags.DEFINE_string('env_name', 'halfcheetah-expert-v2', 'Environment name.')
flags.DEFINE_enum('dataset_name', 'd4rl', ['d4rl', 'awac', 'rl_unplugged'],
                  'Dataset name.')
flags.DEFINE_string('exp_prefix', 'test', 'Name of experiment')
flags.DEFINE_string('exp_descriptor', 'sac', 'Name of experiment')

flags.DEFINE_string('save_dir', '../..1/tmp/', 'Tensorboard logging dir.')
flags.DEFINE_integer('seed', 42, 'Random seed.')
flags.DEFINE_integer('eval_episodes', 100,
                     'Number of episodes used for evaluation.')
flags.DEFINE_integer('log_interval', 1000, 'Logging interval.')
flags.DEFINE_integer('eval_interval', 5000, 'Eval interval.')
flags.DEFINE_integer('save_interval', 25000, 'Eval interval.')
flags.DEFINE_integer('batch_size', 256, 'Mini batch size.')
flags.DEFINE_integer('max_steps', int(1e6), 'Number of training steps.')
flags.DEFINE_float(
    'percentile', 100.0,
    'Dataset percentile (see https://arxiv.org/abs/2106.01345).')
flags.DEFINE_float('percentage', 100.0,
                   'Pencentage of the dataset to use for training.')
flags.DEFINE_boolean('tqdm', True, 'Use tqdm progress bar.')
flags.DEFINE_boolean('save_video', False, 'Save videos during evaluation.')
config_flags.DEFINE_config_file(
    'config',
    'configs/discrete_default.py',
    'File path to the training hyperparameter configuration.',
    lock_config=False)


def main(_):
    FLAGS.seed = np.random.choice(1000000)
    FLAG_DICT = {k: getattr(FLAGS, k) for k in FLAGS}
    FLAG_DICT.update({k: FLAGS.config[k] for k in FLAGS.config})

    FLAGS.exp_descriptor = FLAGS.exp_descriptor.format(**FLAG_DICT)
    unique_identifier = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    exp_id = f'{FLAGS.exp_descriptor}_{unique_identifier}' #uuid.uuid4().hex
    FLAGS.save_dir = os.path.join(FLAGS.save_dir, FLAGS.exp_prefix, exp_id)
    os.makedirs(FLAGS.save_dir, exist_ok=True)

    video_save_folder = None if not FLAGS.save_video else os.path.join(
        FLAGS.save_dir, 'video', 'eval')
    if 'dict' in FLAGS.env_name.lower():
        env, dataset = make_dictenv_and_dataset(FLAGS.env_name, FLAGS.seed,
                                            FLAGS.dataset_name, video_save_folder, True)
    else:
        env, dataset = make_env_and_dataset(FLAGS.env_name, FLAGS.seed,
                                            FLAGS.dataset_name, video_save_folder)
        dataset = DatasetWrapper(dataset)

    config = FLAGS.config
    wandb_logger = WandBLogger(dict(), dict(config), exp_prefix=FLAGS.exp_prefix, exp_descriptor=FLAGS.exp_descriptor, unique_identifier=unique_identifier)

    if FLAGS.percentage < 100.0:
        dataset.take_random(FLAGS.percentage)

    if FLAGS.percentile < 100.0:
        dataset.take_top(FLAGS.percentile)

    kwargs = dict(FLAGS.config)
    # kwargs['num_steps'] = FLAGS.max_steps
    kwargs.pop('algo')
    kwargs.pop('replay_buffer_size')
    example_obs = env.reset()
    if not isinstance(example_obs, dict):
        example_obs = {'observation': example_obs}
    action_dim = env.action_space.n
    agent = SACLearner(FLAGS.seed,
                           {k: v[None] for k, v in example_obs.items()},
                           np.array([env.action_space.sample()]), action_dim=action_dim, **kwargs)

    eval_returns = []
    for i in tqdm.tqdm(range(1, FLAGS.max_steps + 1),
                       smoothing=0.1,
                       disable=not FLAGS.tqdm):
        batch = dataset.sample(FLAGS.batch_size)

        update_info = agent.update(batch)
        train_metrics = dict(iteration=i)
        for k, v in update_info.items():
            train_metrics[f'training/{k}'] = v
        
        debug_info = agent.debug_log(batch)
        for k, v in debug_info.items():
            train_metrics[f'debug/{k}'] = v

        if i % FLAGS.log_interval == 0:
            wandb_logger.log(train_metrics, step=i)
            print({k: float(v) for k, v in train_metrics.items()})

        if i % FLAGS.eval_interval == 0:
            eval_stats = evaluate(agent, env, FLAGS.eval_episodes, )
            eval_metrics = dict()
            for k, v in eval_stats.items():
                eval_metrics[f'evaluation/average_{k}s'] = v

            adapt_eval_stats = evaluate(agent, env, FLAGS.eval_episodes, adapt=True)
            for k, v in adapt_eval_stats.items():
                eval_metrics[f'adaptive_evaluation/average_{k}s'] = v

            conservative_eval_stats = evaluate(agent, env, FLAGS.eval_episodes, adapt=False, conservative=True)
            for k, v in conservative_eval_stats.items():
                eval_metrics[f'conservative_evaluation/average_{k}s'] = v

            wandb_logger.log(eval_metrics, step=i)

            # eval_returns.append((i, eval_stats['return']))
            # np.savetxt(os.path.join(FLAGS.save_dir, f'{FLAGS.seed}.txt'),
            #            eval_returns,
            #            fmt=['%d', '%.1f'])


        if i % FLAGS.save_interval == 0:
            state_dict =  agent.serialize()
            
            import gzip
            import pickle
            fname = os.path.join(FLAGS.save_dir, f'iter_{i}.gz')
            print(f'Saving to {fname}')
            with gzip.open(fname, "wb") as f:
                pickle.dump(state_dict, f)
if __name__ == '__main__':
    app.run(main)
