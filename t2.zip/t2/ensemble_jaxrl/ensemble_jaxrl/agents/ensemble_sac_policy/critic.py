from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from ensemble_jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic
import functools as ft
from ensemble_jaxrl.agents.ensemble_sac_policy import ensemble_networks


def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)


def update(key: PRNGKey, actor: Model, critic: Model, state_critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float, n_ensemble: int,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    key, rng = jax.random.split(key, 2)
    contexts = ensemble_networks.sample_context(rng, n_ensemble, (len(batch.actions),))
    # curr_pred = critic(batch.observations, contexts, batch.actions)
    # ic(state_critic(batch.next_observations, contexts))
    # next_pred = batch.rewards[..., None] + discount * batch.masks[..., None] * state_critic(batch.next_observations, contexts)
    # error = jnp.abs(curr_pred - next_pred)
    next_contexts = contexts #ensemble_networks.update_context(contexts, error)

    dist = actor(batch.next_observations, next_contexts)
    next_actions = dist.sample(seed=key)
    next_log_probs = dist.log_prob(next_actions)
    (next_q1, next_q2), next_q_aux, next_q_repr = target_critic(batch.next_observations, next_contexts, next_actions, diff_actions=True, method=target_critic.model_def.get_value_and_aux)
    ic(next_q1.shape, next_q_aux.shape, next_q_repr.shape)

    # next_q_ensemble = target_critic(batch.next_observations, next_contexts, next_actions, method=target_critic.model_def.get_q_different_actions)

    next_q = next_q1#jnp.minimum(next_q1, next_q2) #next_q_ensemble
    # next_q = jnp.min(next_q_ensemble, axis=-1)[..., None]
    
    target_q = batch.rewards[..., None] + discount * batch.masks[..., None] * next_q
    if backup_entropy:
        target_q -= (discount * batch.masks * temp())[..., None] *  next_log_probs
    ic(next_q.shape, target_q.shape)
 
    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        (q1, q2), curr_aux, curr_repr = critic.apply_fn({'params': critic_params}, batch.observations, contexts,
                                 batch.actions, method=critic.model_def.get_value_and_aux)
        ic(q1.shape, target_q.shape)
        critic_loss = ((q1 - target_q)**2).mean() + ((q2 - target_q)**2).mean()
        ic(((q1 - target_q)**2).shape)
        
        r_pred = curr_aux[..., 0]
        phi_pred = curr_aux[..., 1:]
        phi_loss = ((phi_pred - next_q_repr) ** 2)
        r_loss = (r_pred - batch.rewards[..., None]) ** 2
        ic(r_loss.shape, phi_loss.shape)
        reg_loss = r_loss.mean() + phi_loss.sum(-1).mean()
        
        grad_loss = 0

        return critic_loss + grad_loss, {# + reg_loss, {
            'critic_loss': critic_loss,
            'q1': q1.mean(),
            'grad_loss': grad_loss,
            # 'r_loss': r_loss.mean(),
            # 'phi_loss': phi_loss.mean(),
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)

    return new_critic, info
