from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from ensemble_jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from ensemble_jaxrl.agents.ensemble_sac_policy import ensemble_networks

from icecream import ic

def update(key: PRNGKey, actor: Model, critic: Model, state_critic: Model, temp: Model,
           batch: Batch, n_ensemble: int) -> Tuple[Model, InfoDict]:
    key, rng = jax.random.split(key, 2)
    contexts = ensemble_networks.sample_context(rng, n_ensemble, (len(batch.actions),))

    def actor_loss_fn(actor_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        print(contexts.shape)
        dist = actor.apply_fn({'params': actor_params}, batch.observations, contexts)
        actions = dist.sample(seed=key)
        ic(actions.shape)
        log_probs = dist.log_prob(actions)
        q1, q2 = critic(batch.observations, contexts, actions, method=critic.model_def.get_q_different_actions)
        q = jnp.minimum(q1, q2) # ensemble_q
        # q = jnp.sum(contexts * ensemble_q, axis=-1)

        actor_loss = (log_probs * temp() - q).mean()
        return actor_loss, {
            'q_pi_actor': q.mean(),
            'actor_loss': actor_loss,
            'entropy': -log_probs.mean()
        }

    new_actor, actor_info = actor.apply_gradient(actor_loss_fn)
    new_state_critic, state_critic_info = state_critic, {}#state_critic.apply_gradient(state_critic_loss_fn)

    return new_actor, new_state_critic, {**actor_info, **state_critic_info}
