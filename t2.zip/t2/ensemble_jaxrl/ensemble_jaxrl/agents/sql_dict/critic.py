from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic

def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)

def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    all_next_q = target_critic(batch.next_observations, method=target_critic.model_def.get_all_q)
    next_q_probs = jax.nn.softmax(all_next_q / temp(), axis=-1)
    ic(next_q_probs.shape, all_next_q.shape)
    next_v = (all_next_q * next_q_probs).sum(-1)
    target_q = batch.rewards + discount * batch.masks * next_v
    ic(target_q.shape)
    # if backup_entropy:
    #     target_q -= discount * batch.masks * temp() * next_log_probs

    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        all_q = critic.apply_fn({'params': critic_params}, batch.observations,
                                 method=critic.model_def.get_all_q)
        q = all_q[jnp.arange(len(batch.actions)), batch.actions]
        ic(q.shape)
        critic_loss = ((q - target_q)**2).mean()
        return critic_loss, {
            'critic_loss': critic_loss,
            'q1': q.mean(),
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)

    return new_critic, info
