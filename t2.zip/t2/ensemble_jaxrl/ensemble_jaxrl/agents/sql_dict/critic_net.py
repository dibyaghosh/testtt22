"""Implementations of algorithms for continuous control."""

from typing import Callable, Sequence, Tuple, Optional

import jax.numpy as jnp
from flax import linen as nn

from jaxrl.networks.common import MLP
from jaxrl.networks import policies
from tensorflow_probability.substrates import jax as tfp
from icecream import ic
tfd = tfp.distributions
tfb = tfp.bijectors
import jax

class CNNHead(nn.Module):
  @nn.compact
  def __call__(self, x):
    x = jnp.moveaxis(x, -3, -1)
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = x.reshape((*x.shape[:-3], -1))
    x = jax.lax.stop_gradient(x)
    x = nn.Dense(4)(x)
    return x

class MLPWithImage(nn.Module):
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    activate_final: int = False
    dropout_rate: Optional[float] = None
    has_image: bool = False

    def setup(self):
        if self.has_image:
            self.cnn = CNNHead()
        self.mlp = MLP(self.hidden_dims, self.activations, self.dropout_rate)
    
    def __call__(self, x, image, training=False):
        if self.has_image:
            z = self.cnn(image)
            ic('CNN', x.shape, z.shape)
            x = jnp.concatenate([x, z], axis=-1)
        return self.mlp(x)

# class ValueCritic(nn.Module):
#     hidden_dims: Sequence[int]

#     @nn.compact
#     def __call__(self, observations: jnp.ndarray, images) -> jnp.ndarray:
#         critic = MLPWithImage((*self.hidden_dims, 1))(observations, images)
#         return jnp.squeeze(critic, -1)


class Critic(nn.Module):
    action_dim: int
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    has_image: bool = False

    def setup(self):
        self.net = MLPWithImage((*self.hidden_dims, self.action_dim),
                     activations=self.activations, has_image=self.has_image)

    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> jnp.ndarray:
        obs = observations['observation']
        images = observations.get('descriptor', None)
        inputs = obs#jnp.concatenate([obs, actions], -1)
        critic = self.net(inputs, images)
        return critic[jnp.arange(len(obs)), actions]

    def get_all_q(self, observations):
        obs = observations['observation']
        images = observations.get('descriptor', None)
        inputs = obs#jnp.concatenate([obs, actions], -1)
        critic = self.net(inputs, images)
        return critic

class DoubleCritic(nn.Module):
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    has_image: bool = False

    def setup(self):
        self.net1 = Critic(self.hidden_dims,
                         activations=self.activations, has_image=self.has_image)
        self.net2 = Critic(self.hidden_dims,
                         activations=self.activations, has_image=self.has_image)

    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        critic1 = self.net1(observations, actions)
        critic2 = self.net2(observations, actions)
        return critic1, critic2

@jax.jit
def sample_actions(rng, critic, observations, temperature):
    q = critic(observations, method=critic.model_def.get_all_q)
    probs = jax.nn.softmax(q / temperature(), axis=-1)
    dist = tfd.Categorical(probs=probs)
    return dist.sample(seed=rng)