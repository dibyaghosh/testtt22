
from typing import Callable, Sequence, Tuple

import jax
import jax.numpy as jnp
from flax import linen as nn

from jaxrl.networks.common import MLP, default_init

class EnsembleMLP(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    independent: bool = True

    @nn.compact
    def __call__(self, xs):
        if self.independent:
            VmapMLP = nn.vmap(MLP, variable_axes={'params': 0}, split_rngs={'params': True}, in_axes=None, out_axes=-1, axis_size=self.n_ensemble)
            y = VmapMLP((*self.hidden_dims, 1), activations=self.activations)(xs)
            y = jnp.squeeze(y, -2)
            return y
        else:
            mlp = MLP((*self.hidden_dims, self.n_ensemble), activations=self.activations)(xs)
            return mlp

class Critic(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    independent: bool = True

    def setup(self):
        self.net = EnsembleMLP(self.hidden_dims, self.n_ensemble,
                     activations=self.activations, independent=self.independent)

    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> jnp.ndarray:
        inputs = jnp.concatenate([observations, actions], -1)
        return self.net(inputs)
