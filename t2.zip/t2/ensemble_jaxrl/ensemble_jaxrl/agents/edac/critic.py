from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from ensemble_jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic
import functools as ft
def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)


def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    dist = actor(batch.next_observations)
    next_actions = dist.sample(seed=key)
    next_log_probs = dist.log_prob(next_actions)
    next_q_ensemble = target_critic(batch.next_observations, next_actions)
    # next_q = next_q_ensemble
    next_q = jnp.min(next_q_ensemble, axis=-1)[..., None]
    target_q = batch.rewards[..., None] + discount * batch.masks[..., None] * next_q
    if backup_entropy:
        target_q -= (discount * batch.masks * temp() * next_log_probs)[..., None]
    ic(next_q.shape, target_q.shape)

    def get_q(critic_params, obs, act):
        return critic.apply_fn({'params': critic_params}, obs, act)
    get_q_jacobian = jax.jacfwd(get_q, argnums=2)

    @ft.partial(jax.vmap, in_axes=(None, 0, 0), out_axes=0)
    def get_jacobian(critic_params, obs, act):
        X = get_q_jacobian(critic_params, obs, act)
        return X
    
    sample_size = batch.actions.shape[-1]
    indices = jax.random.choice(key, next_q_ensemble.shape[-1], shape=(sample_size,))

    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        q_ensemble = critic.apply_fn({'params': critic_params}, batch.observations,
                                 batch.actions)
        ic(q_ensemble.shape, target_q.shape)
        critic_loss = ((q_ensemble - target_q)**2).mean()
        ic(((q_ensemble - target_q)**2).shape)

        qs_pred_grads = get_jacobian(critic_params, batch.observations, batch.actions)
        qs_pred_grads = qs_pred_grads[:, indices, :]
        qs_pred_grads = qs_pred_grads / (1e-10 + jnp.linalg.norm(qs_pred_grads, axis=2)[..., None])

        qs_pred_grads = jnp.einsum('bik,bjk->bij', qs_pred_grads, qs_pred_grads)
        masks = jnp.tile(jnp.eye(sample_size), (qs_pred_grads.shape[0], 1, 1))
        qs_pred_grads = (1 - masks) * qs_pred_grads
        grad_loss = qs_pred_grads.mean()# jnp.mean(jnp.sum(qs_pred_grads, axis=(1, 2))) / (sample_size - 1)

        return critic_loss + grad_loss, {
            'critic_loss': critic_loss,
            'q1': q_ensemble.mean(),
            'grad_loss': grad_loss,
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)

    return new_critic, info
