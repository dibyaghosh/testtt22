from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic


def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)


def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float, alpha: float,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    dist = actor(batch.next_observations)
    next_actions = dist.sample(seed=key)
    next_log_probs = dist.log_prob(next_actions)
    next_q = target_critic(batch.next_observations, next_actions)
    # next_q = jnp.minimum(next_q1, next_q2)
    target_q = batch.rewards[..., None] + discount * batch.masks[..., None] * next_q
    ic(target_q.shape)

    curr_dist = actor(batch.observations)
    curr_actions = curr_dist.sample(seed=key)

    # if backup_entropy:
    #     target_q -= discount * batch.masks * temp() * next_log_probs

    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        q = critic.apply_fn({'params': critic_params}, batch.observations,
                                 batch.actions)
        critic_loss = ((q - target_q)**2).mean()
        
        q_pi = critic.apply_fn({'params': critic_params}, batch.observations,
                                 curr_actions)

        reg_loss = (q_pi - q).mean()
        return critic_loss + alpha * reg_loss, {
            'critic_loss': critic_loss,
            'reg_loss': reg_loss,
            'q': q.mean(),
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)

    return new_critic, info
