from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic
from tensorflow_probability.substrates import jax as tfp

tfd = tfp.distributions
tfb = tfp.bijectors

def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)

def get_errs(key, critic, actor, batch: Batch, gamma:float):
    levels = critic.model_def.levels
    N = critic.model_def.n_ensemble
    Q_ensemble = critic(batch.observations, batch.actions)
    next_action = actor(batch.next_observations, temperature=0).sample(seed=key)
    errs = []
    def get_kmin(Q, k):
        mask = jnp.arange(N) > levels[k]
        ic(Q.shape, mask.shape)
        return jnp.min(Q + 1e6 * mask)
    get_kmin_vmap = jax.vmap(get_kmin, in_axes=(1, None), out_axes=0)

    for i in range(len(levels)):
        nQi = critic(batch.next_observations, next_action[i])

        Qi = get_kmin_vmap(Q_ensemble[..., i], i)
        nV = get_kmin_vmap(nQi[..., i], i)
        tQi = batch.rewards + gamma * nV
        errs.append(Qi-tQi)
    return jnp.stack(errs, 1)


def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    N = critic.model_def.n_ensemble
    levels = critic.model_def.levels
    ic(levels)
    batch_size = len(batch.observations)
    def get_kmin(Q, k):
        mask = jnp.arange(N) > levels[k]
        ic(Q.shape, mask.shape)
        return jnp.min(Q + 1e6 * mask)

    errs = get_errs(key, critic, actor, batch, discount) ** 2
    mean_err = 0
    # std_err = jnp.median(jnp.abs(errs - jnp.median(errs)))#, 1, keepdims=True)
from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic
from tensorflow_probability.substrates import jax as tfp

tfd = tfp.distributions
tfb = tfp.bijectors

def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)

def get_errs(key, critic, actor, batch: Batch, gamma:float):
    levels = critic.model_def.levels
    N = critic.model_def.n_ensemble
    Q_ensemble = critic(batch.observations, batch.actions)
    next_action = actor(batch.next_observations, temperature=0).sample(seed=key)
    errs = []
    def get_kmin(Q, k):
        mask = jnp.arange(N) > levels[k]
        ic(Q.shape, mask.shape)
        return jnp.min(Q + 1e6 * mask)
    get_kmin_vmap = jax.vmap(get_kmin, in_axes=(1, None), out_axes=0)

    for i in range(len(levels)):
        nQi = critic(batch.next_observations, next_action[i])

        Qi = get_kmin_vmap(Q_ensemble[..., i], i)
        nV = get_kmin_vmap(nQi[..., i], i)
        tQi = batch.rewards + gamma * nV
        errs.append(Qi-tQi)
    return jnp.stack(errs, 1)


def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    N = critic.model_def.n_ensemble
    levels = critic.model_def.levels
    ic(levels)
    batch_size = len(batch.observations)
    def get_kmin(Q, k):
        mask = jnp.arange(N) > levels[k]
        ic(Q.shape, mask.shape)
        return jnp.min(Q + 1e6 * mask)

    errs = get_errs(key, critic, actor, batch, discount) ** 2
    mean_err = 0
    std_err = jnp.median(jnp.abs(errs - jnp.median(errs, 1, keepdims=True)), 1, keepdims=True)
    T = jnp.tile(jnp.linspace(1, 100, batch_size)[:, None], (1, len(levels)))
    ic(T.shape, std_err.shape)
    old_err_dist = tfd.Normal(loc=mean_err * T, scale= std_err * T)
    imagined_prev_errs = old_err_dist.sample(seed=key)
    Ks = jnp.argmin(imagined_prev_errs, 1)

    new_imagined_errs = imagined_prev_errs + errs
    next_step_Ks = jnp.argmin(new_imagined_errs, 1)
    # new_K_dist = tfd.Categorical(logits=-1 * errs / mean_err)    
    # ic(errs.shape)
    # Ks = jax.random.randint(key, shape=(batch_size,), minval=0, maxval=len(levels))
    # replacement_Ks = new_K_dist.sample(seed=key)
    # ic(replacement_Ks.shape)
    # next_step_Ks = jnp.where(jax.random.uniform(key, shape=(batch_size,)) < 0.5, Ks, replacement_Ks)
    min_errs = jnp.min(errs, 1)
    actual_errs = errs[jnp.arange(batch_size), Ks]
    new_errs = errs[jnp.arange(batch_size), next_step_Ks]

    dist = actor(batch.next_observations)
    next_actions = dist.sample(seed=key)
    next_log_probs = dist.log_prob(next_actions)
    ic(next_actions.shape)
    next_actions = next_actions[next_step_Ks, jnp.arange(batch_size)] # Batch_size x NA
    next_log_probs = next_log_probs[next_step_Ks, jnp.arange(batch_size)] # Batch_size # Choose action according to next_K 
    ic(next_actions.shape, next_log_probs.shape)

    next_q_ensemble = target_critic(batch.next_observations, next_actions) # N x Batch_size x N
    next_q_ensemble = next_q_ensemble[:, jnp.arange(batch_size), Ks]
    ic(next_q_ensemble.shape) # N x Batch_size

    next_q = jax.vmap(get_kmin, in_axes=(1, 0), out_axes=0)(next_q_ensemble, Ks)
    # next_q = jnp.min(next_q_ensemble, 0)
    ic(next_q.shape)

    target_q = batch.rewards + discount * batch.masks * next_q

    if backup_entropy:
        target_q -= discount * batch.masks * temp() * next_log_probs

    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        q_ensemble = critic.apply_fn({'params': critic_params}, batch.observations,
                                 batch.actions)
        q_ensemble = q_ensemble[:, jnp.arange(batch_size), Ks]
        ic(q_ensemble.shape, target_q.shape)
        critic_loss = ((q_ensemble - target_q)**2).mean() #+ (q2 - target_q)**2).mean()
        # critic_loss = jax.vmap(kmin_loss, in_axes=(1, 0, 0), out_axes=1)(q_ensemble, target_q, Ks)
        # ic(critic_loss.shape)
        # critic_loss = critic_loss.mean()
        return critic_loss, {
            'critic_loss': critic_loss,
            'q1': q_ensemble.mean(),
            'target_q': target_q.mean(),
            'next_q_diff': jnp.abs(next_q - jnp.min(next_q_ensemble, 0)).mean(),
            'critic_K_mean': Ks.astype(float).mean(),
            'err_diff': (actual_errs - min_errs).mean(),
            'err_diff_max': (actual_errs - min_errs).max(),
            'new_err_diff': (new_errs - min_errs).mean(),
            'nK_mean': next_step_Ks.astype(float).mean(),
            'mean_err': mean_err,
            'std_err': std_err.mean(),
            'percent_shifted': (Ks != next_step_Ks).mean(),
            'percent_shifted_from_0': ((Ks != next_step_Ks) * (Ks == 0)).mean() / (1e-10 + (Ks == 0).mean()),
            'percent_shifted_from_N': ((Ks != next_step_Ks) * (Ks == len(levels) - 1)).mean() / (1e-10 + (Ks == len(levels) - 1)).mean(),
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)

    return new_critic, info

# from typing import Tuple

# import jax
# import jax.numpy as jnp

# from jaxrl.datasets import Batch
# from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
# from icecream import ic

# def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
#     new_target_params = jax.tree_multimap(
#         lambda p, tp: p * tau + tp * (1 - tau), critic.params,
#         target_critic.params)

#     return target_critic.replace(params=new_target_params)

# def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
#            temp: Model, batch: Batch, discount: float,
#            backup_entropy: bool) -> Tuple[Model, InfoDict]:
#     levels = critic.model_def.levels
#     batch_size = len(batch.observations)
#     Ks = jax.random.randint(key, shape=(batch_size,), minval=0, maxval=len(levels))
#     dist = actor(batch.next_observations)
#     next_actions = dist.sample(seed=key)
#     next_log_probs = dist.log_prob(next_actions)

#     ic(next_actions.shape)
#     next_actions = next_actions[Ks, jnp.arange(batch_size)] # Batch_size x NA
#     next_log_probs = next_log_probs[Ks, jnp.arange(batch_size)] # Batch_size 
#     ic(next_actions.shape, next_log_probs.shape)

#     next_q_ensemble = target_critic(batch.next_observations, next_actions,
#         method=target_critic.model_def.get_minimum_q) # Batch_size x |Levels|
#     next_q = next_q_ensemble[jnp.arange(batch_size), Ks]
#     ic(next_q_ensemble.shape) # Batch_size x |levels|
#     ic(next_q.shape) # Batch_size

#     target_q = batch.rewards + discount * batch.masks * next_q

#     if backup_entropy:
#         target_q -= discount * batch.masks * temp() * next_log_probs

#     def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
#         q_ensemble = critic.apply_fn({'params': critic_params}, batch.observations,
#                                  batch.actions)
#         q_ensemble = q_ensemble[:, jnp.arange(batch_size), Ks]
#         ic(q_ensemble.shape, target_q.shape)
#         critic_loss = ((q_ensemble - target_q)**2).mean() #+ (q2 - target_q)**2).mean()
#         return critic_loss, {
#             'critic_loss': critic_loss,
#             'q1': q_ensemble.mean(),
#             'target_q': target_q.mean(),
#             'next_q_diff': jnp.abs(next_q - jnp.min(next_q_ensemble, -1)).mean(),
#         }

#     new_critic, info = critic.apply_gradient(critic_loss_fn)

#     return new_critic, info
