"""Implementations of algorithms for continuous control."""

from typing import Callable, Sequence, Tuple, Optional

import jax.numpy as jnp
from flax import linen as nn

from jaxrl.networks.common import MLP
from icecream import ic
from jaxrl.networks import policies
import jax
from tensorflow_probability.substrates import jax as tfp

tfd = tfp.distributions
tfb = tfp.bijectors

class ValueCritic(nn.Module):
    hidden_dims: Sequence[int]

    @nn.compact
    def __call__(self, observations: jnp.ndarray) -> jnp.ndarray:
        critic = MLP((*self.hidden_dims, 1))(observations)
        return jnp.squeeze(critic, -1)

def reshape(Q, level_specification, n_ensemble):
    Q_reshaped = level_specification.dot(Q)
    return Q_reshaped.reshape(-1, n_ensemble)

class Critic(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int
    levels: jnp.ndarray
    level_specification: jnp.ndarray
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    independent: bool = True

    def setup(self):
        if self.independent:
            VmapMLP = nn.vmap(MLP, variable_axes={'params': 0},
                split_rngs={'params': True}, in_axes=None, out_axes=-2,
                axis_size=jnp.sum(self.levels+1))
            self.net = VmapMLP((*self.hidden_dims, 1),
                        activations=self.activations)

        else:
            VmapMLP = nn.vmap(MLP, variable_axes={'params': 0},
                split_rngs={'params': True}, in_axes=None, out_axes=0,
                axis_size=self.n_ensemble)
            self.net = VmapMLP((*self.hidden_dims, len(self.levels)),
                        activations=self.activations)

    @nn.compact
    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> jnp.ndarray:
        inputs = jnp.concatenate([observations, actions], -1)
        critic = self.net(inputs)
        ic(critic.shape)
        if self.independent:
            critic = jnp.squeeze(critic, -1)
            if len(critic.shape) == 1: # No batch dim
                critic = reshape(critic, self.level_specification, self.n_ensemble)
                critic = jnp.moveaxis(critic, -1, 0)
                ic('After reshape', critic.shape)
                return critic
            critic = jax.vmap(reshape, in_axes=(0, None, None), out_axes=0)(critic, self.level_specification, self.n_ensemble)
            critic = jnp.moveaxis(critic, -1, 0)
            ic('After reshape', critic.shape)
            return critic
        return critic#jnp.squeeze(critic, -1)
    

class PolicyBase(nn.Module):
    hidden_dims: Sequence[int]
    action_dim: int
    state_dependent_std: bool = True
    dropout_rate: Optional[float] = None
    final_fc_init_scale: float = 1.0
    log_std_min: Optional[float] = None
    log_std_max: Optional[float] = None
    tanh_squash_distribution: bool = True
    init_mean: Optional[jnp.ndarray] = None

    @nn.compact
    def __call__(self, observations: jnp.ndarray):
        outputs = MLP(self.hidden_dims,
                      activate_final=True,
                      dropout_rate=self.dropout_rate)(observations)

        means = nn.Dense(self.action_dim,
                         kernel_init=policies.default_init(
                             self.final_fc_init_scale))(outputs)
        if self.init_mean is not None:
            means += self.init_mean

        if self.state_dependent_std:
            log_stds = nn.Dense(self.action_dim,
                                kernel_init=policies.default_init(
                                    self.final_fc_init_scale))(outputs)
        else:
            log_stds = self.param('log_stds', nn.initializers.zeros,
                                  (self.action_dim, ))

        log_std_min = self.log_std_min or policies.LOG_STD_MIN
        log_std_max = self.log_std_max or policies.LOG_STD_MAX
        log_stds = jnp.clip(log_stds, log_std_min, log_std_max)

        if not self.tanh_squash_distribution:
            means = nn.tanh(means)
        return means, log_stds

class NormalTanhPolicy(nn.Module):
    levels: jnp.ndarray
    hidden_dims: Sequence[int]
    action_dim: int
    state_dependent_std: bool = True
    dropout_rate: Optional[float] = None
    final_fc_init_scale: float = 1.0
    log_std_min: Optional[float] = None
    log_std_max: Optional[float] = None
    tanh_squash_distribution: bool = True
    init_mean: Optional[jnp.ndarray] = None

    @nn.compact
    def __call__(self,
                 observations: jnp.ndarray,
                 temperature: float = 1.0,
                 training: bool = False) -> tfd.Distribution:
        VmapPolicy = nn.vmap(PolicyBase, variable_axes={'params': 0},
            split_rngs={'params': True}, in_axes=None, out_axes=(0, 0),
            axis_size=len(self.levels))
        means, log_stds = VmapPolicy(self.hidden_dims,
            self.action_dim,
            init_mean=self.init_mean,
            final_fc_init_scale=self.final_fc_init_scale)(observations)

        base_dist = tfd.MultivariateNormalDiag(loc=means,
                                               scale_diag=jnp.exp(log_stds) *
                                               temperature)
        if self.tanh_squash_distribution:
            return tfd.TransformedDistribution(distribution=base_dist,
                                               bijector=tfb.Tanh())
        else:
            return base_dist