"""Implementations of algorithms for continuous control."""

from typing import Callable, Sequence, Tuple, Optional

import jax.numpy as jnp
from flax import linen as nn

from jaxrl.networks.common import MLP
from jaxrl.networks import policies
from tensorflow_probability.substrates import jax as tfp
from icecream import ic
tfd = tfp.distributions
tfb = tfp.bijectors
import jax

def sample_context(rng, n_ensemble, shape):
    return jax.random.dirichlet(rng, jnp.ones(n_ensemble) * 0.1, shape=shape)

def update_context(c, error):
    new_contexts = jax.nn.softmax(jnp.log(c) - jnp.abs(error), axis=-1)
    new_contexts = jnp.clip(new_contexts, 0.0001, 1)
    new_contexts = new_contexts / new_contexts.sum(-1, keepdims=True)
    return new_contexts

class CNNHead(nn.Module):
  @nn.compact
  def __call__(self, x):
    x = jnp.moveaxis(x, -3, -1)
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = x.reshape((*x.shape[:-3], -1))
    # x = jax.lax.stop_gradient(x)
    x = nn.Dense(10)(x)
    return x

class MLPWithImage(nn.Module):
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    activate_final: int = False
    dropout_rate: Optional[float] = None
    has_image: bool = False

    def setup(self):
        if self.has_image:
            self.cnn = CNNHead()
        self.mlp = MLP(self.hidden_dims, self.activations, self.dropout_rate)
    
    def __call__(self, x, image, training=False):
        if self.has_image:
            z = self.cnn(image)
            ic('CNN', image.shape, x.shape, z.shape)
            x = jnp.concatenate([x, z], axis=-1)
        return self.mlp(x)

    def get_cnn(self, x, image):
        return self.cnn(image)


class Critic(nn.Module):
    action_dim: int
    n_ensemble: int
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    has_image: bool = False

    def setup(self):
        VmapMLP = nn.vmap(MLPWithImage, variable_axes={'params': 0}, split_rngs={'params': True}, in_axes=None, out_axes=-2, axis_size=self.n_ensemble,
            methods=('__call__', 'get_cnn'))
        self.net = VmapMLP((*self.hidden_dims, self.action_dim), activations=self.activations, has_image=self.has_image)

    def __call__(self, observations: jnp.ndarray, contexts: jnp.ndarray,
                 actions: jnp.ndarray) -> jnp.ndarray:
        critic = self.get_all_q(observations, contexts)
        return critic[jnp.arange(len(actions)), :, actions] # batch x n_ensemble

    def get_all_q(self, observations, contexts):
        obs = observations['observation']
        images = observations.get('descriptor', None)
        inputs = jnp.concatenate([obs, contexts], -1)
        critic = self.net(inputs, images)
        return critic # batch x n_ensemble x n_actions

@jax.jit
def sample_actions(rng, critic, observations, contexts, temperature):
    q = critic(observations, contexts, method=critic.model_def.get_all_q)
    ps = jax.nn.softmax(q / temperature, axis=-1)
    probs = (ps * contexts[..., None]).sum(-2)
    # q = (q * contexts[..., None]).sum(-2)
    # probs = jax.nn.softmax(q / temperature, axis=-1)
    dist = tfd.Categorical(probs=probs)
    return dist.sample(seed=rng)