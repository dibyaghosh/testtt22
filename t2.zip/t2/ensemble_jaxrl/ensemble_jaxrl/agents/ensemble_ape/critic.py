from typing import Tuple

import jax
import jax.numpy as jnp
from ensemble_jaxrl.contextual_dataset import EnsembleBatch as Batch
# from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic
from ensemble_jaxrl.agents.ensemble_ape.critic_net import sample_context, update_context
import functools as ft

def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)

@ft.partial(jax.vmap, in_axes=0, out_axes=0)
def get_v(qs, contexts):
    """
    qs: (n_ensemble, a)
    contexts: (n_ensemble,)
    """
    ps = jax.nn.softmax(qs / 0.001, -1) # n_ensemble, a
    p = (ps * contexts[..., None]).sum(0) # a
    # q = (qs * contexts[..., None]).sum(0) # (a)
    # p = jax.nn.softmax(q / 0.05, -1) # (a)
    v = (qs * p).sum(1) # (n_ensemble)
    # ic(qs.shape, contexts.shape, q.shape, p.shape, v.shape)
    return v #(n_ensemble, )

def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    ic(batch.ensemble_masks.shape)
    contexts = sample_context(key, critic.model_def.n_ensemble, shape=(len(batch.actions),))
    
    # Compute next context
    curr_q = critic(batch.observations, contexts, batch.actions) # (batch, n_ensemble)
    all_next_q = target_critic(batch.next_observations, contexts, method=target_critic.model_def.get_all_q)
    next_v = get_v(all_next_q, contexts) # 
    residual_error = (curr_q - (batch.rewards[..., None] + discount * batch.masks[..., None] * next_v))**2
    ic(residual_error.shape) # Should be (batch, n_ensemble)
    new_contexts = update_context(contexts, residual_error)


    all_next_q = target_critic(batch.next_observations, new_contexts, method=target_critic.model_def.get_all_q)
    next_v = get_v(all_next_q, new_contexts)#(all_next_q * next_q_probs).sum(-1)
    target_q = batch.rewards[..., None] + discount * batch.masks[..., None] * next_v
    ensemble_masks = batch.ensemble_masks[:, :critic.model_def.n_ensemble]
    ic(target_q.shape, ensemble_masks.shape)
    # if backup_entropy:
    #     target_q -= discount * batch.masks * temp() * next_log_probs

    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        all_q = critic.apply_fn({'params': critic_params}, batch.observations, contexts,
                                 method=critic.model_def.get_all_q)
        q = all_q[jnp.arange(len(batch.actions)), :, batch.actions]
        ic(q.shape)
        critic_loss = (q - target_q)**2
        critic_loss = (critic_loss * ensemble_masks).mean()
        critic_loss = critic_loss / (1e-10 + ensemble_masks.mean())
        return critic_loss, {
            'critic_loss': critic_loss,
            'q1': q.mean(),
            'residual_error_mean': residual_error.mean(),
            'residual_error_max': residual_error.max(),
            'ensemble_mask_mean': ensemble_masks.mean()
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)
    return new_critic, info
