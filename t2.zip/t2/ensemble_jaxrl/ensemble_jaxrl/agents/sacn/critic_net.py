"""Implementations of algorithms for continuous control."""

from typing import Callable, Sequence, Tuple

import jax.numpy as jnp
from flax import linen as nn

from jaxrl.networks.common import MLP


class ValueCritic(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int

    @nn.compact
    def __call__(self, observations: jnp.ndarray) -> jnp.ndarray:
        VmapMLP = nn.vmap(MLP, variable_axes={'params': 0},
            split_rngs={'params': True}, in_axes=None, out_axes=-2,
            axis_size=self.n_ensemble)
        critic = VmapMLP((*self.hidden_dims, 1))(observations)
        return jnp.squeeze(critic, -1)

class Critic(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu

    @nn.compact
    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> jnp.ndarray:
        inputs = jnp.concatenate([observations, actions], -1)
        VmapMLP = nn.vmap(MLP, variable_axes={'params': 0},
            split_rngs={'params': True}, in_axes=None, out_axes=-2,
            axis_size=self.n_ensemble)
        critic = VmapMLP((*self.hidden_dims, 1),
                     activations=self.activations)(inputs)
        return jnp.squeeze(critic, -1)

class DoubleCritic(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu

    @nn.compact
    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        critic1 = Critic(self.hidden_dims, self.n_ensemble,
                         activations=self.activations)(observations, actions)
        critic2 = Critic(self.hidden_dims, self.n_ensemble,
                         activations=self.activations)(observations, actions)
        return critic1, critic2
