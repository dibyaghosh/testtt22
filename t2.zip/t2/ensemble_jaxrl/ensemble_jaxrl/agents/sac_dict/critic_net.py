"""Implementations of algorithms for continuous control."""

from typing import Callable, Sequence, Tuple, Optional

import jax.numpy as jnp
from flax import linen as nn

from jaxrl.networks.common import MLP
from jaxrl.networks import policies
from tensorflow_probability.substrates import jax as tfp
from icecream import ic
tfd = tfp.distributions
tfb = tfp.bijectors
import jax

class CNNHead(nn.Module):
  @nn.compact
  def __call__(self, x):
    x = jnp.moveaxis(x, -3, -1)
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = x.reshape((*x.shape[:-3], -1))
    x = jax.lax.stop_gradient(x)
    x = nn.Dense(4)(x)
    return x

class MLPWithImage(nn.Module):
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    activate_final: int = False
    dropout_rate: Optional[float] = None
    has_image: bool = False

    def setup(self):
        if self.has_image:
            self.cnn = CNNHead()
        self.mlp = MLP(self.hidden_dims, self.activations, self.dropout_rate)
    
    def __call__(self, x, image, training=False):
        if self.has_image:
            z = self.cnn(image)
            ic('CNN', x.shape, z.shape)
            x = jnp.concatenate([x, z], axis=-1)
        return self.mlp(x)

class ValueCritic(nn.Module):
    hidden_dims: Sequence[int]

    @nn.compact
    def __call__(self, observations: jnp.ndarray, images) -> jnp.ndarray:
        critic = MLPWithImage((*self.hidden_dims, 1))(observations, images)
        return jnp.squeeze(critic, -1)


class Critic(nn.Module):
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    has_image: bool = False

    def setup(self):
        self.net = MLPWithImage((*self.hidden_dims, 1),
                     activations=self.activations, has_image=self.has_image)

    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> jnp.ndarray:
        obs = observations['observation']
        images = observations.get('descriptor', None)
        inputs = jnp.concatenate([obs, actions], -1)
        critic = self.net(inputs, images)
        return jnp.squeeze(critic, -1)


class DoubleCritic(nn.Module):
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    has_image: bool = False

    def setup(self):
        self.net1 = Critic(self.hidden_dims,
                         activations=self.activations, has_image=self.has_image)
        self.net2 = Critic(self.hidden_dims,
                         activations=self.activations, has_image=self.has_image)

    def __call__(self, observations: jnp.ndarray,
                 actions: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        critic1 = self.net1(observations, actions)
        critic2 = self.net2(observations, actions)
        return critic1, critic2


class NormalTanhPolicy(nn.Module):
    hidden_dims: Sequence[int]
    action_dim: int
    state_dependent_std: bool = True
    dropout_rate: Optional[float] = None
    final_fc_init_scale: float = 1.0
    log_std_min: Optional[float] = None
    log_std_max: Optional[float] = None
    tanh_squash_distribution: bool = True
    init_mean: Optional[jnp.ndarray] = None
    has_image: bool = False

    @nn.compact
    def __call__(self,
                 observations: jnp.ndarray,
                 temperature: float = 1.0,
                 training: bool = False) -> tfd.Distribution:

        obs = observations['observation']
        images = observations.get('descriptor', None)

        outputs = MLPWithImage(self.hidden_dims,
                      activate_final=True,
                      dropout_rate=self.dropout_rate, has_image=self.has_image)(obs, images,
                                                      training=training)

        means = nn.Dense(self.action_dim,
                         kernel_init=policies.default_init(
                             self.final_fc_init_scale))(outputs)
        if self.init_mean is not None:
            means += self.init_mean

        if self.state_dependent_std:
            log_stds = nn.Dense(self.action_dim,
                                kernel_init=policies.default_init(
                                    self.final_fc_init_scale))(outputs)
        else:
            log_stds = self.param('log_stds', nn.initializers.zeros,
                                  (self.action_dim, ))

        log_std_min = self.log_std_min or policies.LOG_STD_MIN
        log_std_max = self.log_std_max or policies.LOG_STD_MAX
        log_stds = jnp.clip(log_stds, log_std_min, log_std_max)

        if not self.tanh_squash_distribution:
            means = nn.tanh(means)

        base_dist = tfd.MultivariateNormalDiag(loc=means,
                                               scale_diag=jnp.exp(log_stds) *
                                               temperature)
        if self.tanh_squash_distribution:
            return tfd.TransformedDistribution(distribution=base_dist,
                                               bijector=tfb.Tanh())
        else:
            return base_dist