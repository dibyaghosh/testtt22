from typing import Tuple

import jax
import jax.numpy as jnp
from ensemble_jaxrl.contextual_dataset import EnsembleBatch as Batch
# from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic
import functools as ft

def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)

def project_distribution(supports, weights, target_support):
  """Projects a batch of (support, weights) onto target_support.x
  Args:
    supports: Jax array of shape (num_dims) defining supports for
      the distribution.
    weights: Jax array of shape (num_dims) defining weights on the
      original support points. Although for the CategoricalDQN agent these
      weights are probabilities, it is not required that they are.
    target_support: Jax array of shape (num_dims) defining support of the
      projected distribution.
  Returns:
    A Jax array of shape (num_dims) with the projection of a batch
    of (support, weights) onto target_support.
  """
  v_min, v_max = target_support[0], target_support[-1]
  num_dims = target_support.shape[0]
  delta_z = (v_max - v_min) / (num_dims - 1)
  clipped_support = jnp.clip(supports, v_min, v_max)
  numerator = jnp.abs(clipped_support - target_support[:, None])
  quotient = 1 - (numerator / delta_z)
  clipped_quotient = jnp.clip(quotient, 0, 1)
  inner_prod = clipped_quotient * weights
  return jnp.squeeze(jnp.sum(inner_prod, -1))


def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    next_state_target_outputs = target_critic(batch.next_observations, method=target_critic.model_def.get_all_q)
    support = jnp.linspace(target_critic.model_def.v_min, target_critic.model_def.v_max, target_critic.model_def.n_atoms)

    @ft.partial(jax.vmap, in_axes=(0, 0, 0, 0))
    def compute_target(reward, mask, next_q, probabilities):
      target_support = reward + discount * mask * support
      ic(target_support.shape)
      next_q_argmax = jnp.argmax(next_q)
      next_probabilities = probabilities[next_q_argmax]
      return project_distribution(target_support, next_probabilities, support)
    
    ensemble_compute_target = jax.vmap(compute_target, in_axes=(None, None, 0, 0))
    target_dist = ensemble_compute_target(batch.rewards, batch.masks, next_state_target_outputs.q_values, next_state_target_outputs.probabilities)
    ic(target_dist.shape)
    # if backup_entropy:
    #     target_q -= discount * batch.masks * temp() * next_log_probs
    ensemble_masks = jnp.moveaxis(batch.ensemble_masks, 1, 0)[:critic.model_def.n_ensemble]
    ic(batch.ensemble_masks.shape, ensemble_masks.shape)
    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        q_outputs = critic.apply_fn({'params': critic_params}, batch.observations,
                                 method=critic.model_def.get_all_q)
        q_logits = q_outputs.logits[:, jnp.arange(len(batch.actions)), batch.actions]
        ic(q_logits.shape, target_dist.shape)
        critic_loss = -1 * jnp.sum(target_dist * jax.nn.log_softmax(q_logits, -1), axis=-1)
        ic(critic_loss.shape)
        critic_loss = (critic_loss * ensemble_masks).mean() / (1e-10 + ensemble_masks.mean())
        return critic_loss, {
            'critic_loss': critic_loss,
            'q1': q_outputs.q_values.mean(),
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)

    return new_critic, info
