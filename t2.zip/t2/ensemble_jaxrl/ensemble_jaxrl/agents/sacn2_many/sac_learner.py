"""Implementations of algorithms for continuous control."""

import functools
from typing import Optional, Sequence, Tuple

import jax
import jax.numpy as jnp
import numpy as np
import optax

from ensemble_jaxrl.agents.sacn2_many import temperature, critic_net
from ensemble_jaxrl.agents.sacn2_many.actor import update as update_actor
from ensemble_jaxrl.agents.sacn2_many.critic import target_update
from ensemble_jaxrl.agents.sacn2_many.critic import update as update_critic
from jaxrl.datasets import Batch
from jaxrl.networks import policies
from ensemble_jaxrl.networks.common import InfoDict, Model, PRNGKey
import flax
from icecream import ic


## EVALUATE IMPORTS
from typing import Dict

import flax.linen as nn
import gym
import numpy as np
from collections import defaultdict, namedtuple
Transition = namedtuple('Transition', ('observation', 'action', 'reward', 'next_observation'))

#####



@functools.partial(jax.jit,
                   static_argnames=('backup_entropy', 'update_target'))
def _update_jit(
    rng: PRNGKey, actor: Model, critic: Model, target_critic: Model,
    temp: Model, batch: Batch, discount: float, tau: float,
    target_entropy: float, backup_entropy: bool, update_target: bool
) -> Tuple[PRNGKey, Model, Model, Model, Model, InfoDict]:

    rng, key = jax.random.split(rng)
    new_critic, critic_info = update_critic(key,
                                            actor,
                                            critic,
                                            target_critic,
                                            temp,
                                            batch,
                                            discount,
                                            backup_entropy=backup_entropy)
    if update_target:
        new_target_critic = target_update(new_critic, target_critic, tau)
    else:
        new_target_critic = target_critic

    rng, key = jax.random.split(rng)
    new_actor, actor_info = update_actor(key, actor, new_critic, temp, batch)
    new_temp, alpha_info = temperature.update(temp, actor_info['entropy'],
                                              target_entropy)

    return rng, new_actor, new_critic, new_target_critic, new_temp, {
        **critic_info,
        **actor_info,
        **alpha_info
    }

import numpy as np

def create_level_specification(levels, n_ensemble):
    N = np.zeros((len(levels) * n_ensemble, sum(levels+1)))
    current_level = 0
    current_idx = 0
    for i in range(sum(levels) + len(levels)):
        # print(i, current_level, current_idx)
        i_index = current_level * n_ensemble + current_idx
        N[i_index, i] = 1
        current_idx += 1
        if current_idx > levels[current_level]:
            current_idx = 0
            current_level += 1
    return N

class SACLearner(object):
    def __init__(self,
                 seed: int,
                 observations: jnp.ndarray,
                 actions: jnp.ndarray,
                 n_ensemble: int,
                 actor_lr: float = 3e-4,
                 critic_lr: float = 3e-4,
                 temp_lr: float = 3e-4,
                 hidden_dims: Sequence[int] = (256, 256),
                 discount: float = 0.99,
                 tau: float = 0.005,
                 target_update_period: int = 1,
                 target_entropy: Optional[float] = None,
                 backup_entropy: bool = True,
                 init_temperature: float = 1.0,
                 init_mean: Optional[np.ndarray] = None,
                 policy_final_fc_init_scale: float = 1.0,
                 independent=True,
                 levels=None,
                 **kwargs):
        """
        An implementation of the version of Soft-Actor-Critic described in https://arxiv.org/abs/1812.05905
        """
        print('Got extra kwargs: ', kwargs)

        action_dim = actions.shape[-1]

        if target_entropy is None:
            self.target_entropy = -action_dim / 2
        else:
            self.target_entropy = target_entropy

        self.backup_entropy = backup_entropy

        self.tau = tau
        self.target_update_period = target_update_period
        self.discount = discount
        self.n_ensemble = n_ensemble
        rng = jax.random.PRNGKey(seed)
        rng, actor_key, critic_key, temp_key = jax.random.split(rng, 4)

        if levels is None:
            if n_ensemble >= 50:
                levels = jnp.linspace(n_ensemble // 2, n_ensemble-1, num=3).astype(int)
            elif n_ensemble >= 20:
                levels = jnp.concatenate([
                    jnp.arange(2, 5), jnp.arange(5, n_ensemble, 2)])
            else:
                levels = jnp.arange(2, n_ensemble)
        # levels = t(np.asarray(levels))
        level_specification = jnp.array(create_level_specification(levels, n_ensemble))
        ic(levels)
        self.levels = levels

        ic(n_ensemble, levels)
        self.acting_id = len(self.levels) - 1
        self.errors = jnp.zeros(len(self.levels))

        actor_def = critic_net.NormalTanhPolicy(
            levels,
            hidden_dims,
            action_dim,
            init_mean=init_mean,
            final_fc_init_scale=policy_final_fc_init_scale)
        actor = Model.create(actor_def,
                             inputs=[actor_key, observations],
                             tx=optax.adam(learning_rate=actor_lr))

        critic_def = critic_net.Critic(hidden_dims, n_ensemble, levels, level_specification, independent=independent)
        critic = Model.create(critic_def,
                              inputs=[critic_key, observations, actions],
                              tx=optax.adam(learning_rate=critic_lr))
        target_critic = Model.create(
            critic_def, inputs=[critic_key, observations, actions])

        temp = Model.create(temperature.Temperature(init_temperature),
                            inputs=[temp_key],
                            tx=optax.adam(learning_rate=temp_lr))

        self.actor = actor
        self.critic = critic
        self.target_critic = target_critic
        self.temp = temp
        self.rng = rng

        self.step = 1


    def sample_actions(self,
                       observations: np.ndarray,
                       temperature: float = 1.0) -> jnp.ndarray:
        rng, actions = policies.sample_actions(self.rng, self.actor.apply_fn,
                                               self.actor.params, observations,
                                               temperature)
        self.rng = rng
        actions = np.asarray(actions)[self.acting_id]
        return np.clip(actions, -1, 1)

    def update(self, batch: Batch) -> InfoDict:
        self.step += 1

        new_rng, new_actor, new_critic, new_target_critic, new_temp, info = _update_jit(
            self.rng, self.actor, self.critic, self.target_critic, self.temp,
            batch, self.discount, self.tau, self.target_entropy,
            self.backup_entropy, self.step % self.target_update_period == 0)

        self.rng = new_rng
        self.actor = new_actor
        self.critic = new_critic
        self.target_critic = new_target_critic
        self.temp = new_temp

        return info

    def parameters(self):
        return {
            'actor': self.actor,
            'critic': self.critic,
            'temp': self.temp,
        }

    def serialize(self):
        return {
            k: flax.serialization.to_bytes(v.params)
            for k, v in self.parameters().items()
        }
    
    def unserialize(self, d):
        parameters = self.parameters()
        return {
            k: flax.serialization.from_bytes(parameters[k].params, d[k])
            for k in parameters
        }

    def load(self, d):
        all_params = self.unserialize(d)
        self.actor = self.actor.replace(params=all_params['actor'])
        self.critic = self.critic.replace(params=all_params['critic'])
        self.target_critic = self.target_critic.replace(params=all_params['critic'])
        self.temp = self.temp.replace(params=all_params['temp'])

    def reset(self):
        self.acting_id = len(self.levels) - 1
        self.errors = jnp.zeros(len(self.levels))
        self.history_transitions = []
    
    def adapt_transition(self, transition: Transition):
        new_errors = get_errs(self.rng, self.critic, self.actor, transition, self.discount)
        self.errors += jnp.where(new_errors > 0, 10 * new_errors ** 2, new_errors ** 2)
        self.acting_id = jnp.argmin(self.errors)
        self.history_transitions.append(self.acting_id)
        if np.random.rand() < 0.0001:
            ic(self.history_transitions)

# @jax.jit
# def get_errs(rng, critic, actor, obs, action, reward, next_obs):
#     levels = critic.model_def.levels
#     Q = critic(obs, action)
#     next_action = actor(next_obs, temperature=0).sample(seed=rng)
#     errs = []
#     for i in range(1, 10):
#         nQi = critic(next_obs, next_action[i])
#         Qi = Q[:i+1, i].min(0)
#         tQi = reward + gamma * nQi[:i+1, i].min(0)
#         errs.append(Qi-tQi)
#     return jnp.stack(errs)

@jax.jit
def get_errs(key, critic, actor, transition: Transition, gamma:float):
    levels = critic.model_def.levels
    N = critic.model_def.n_ensemble
    Q_ensemble = critic(transition.observation, transition.action)
    next_action = actor(transition.next_observation, temperature=0).sample(seed=key)
    errs = []
    def get_kmin(Q, k):
        mask = jnp.arange(N) > levels[k]
        ic(Q.shape, mask.shape)
        return jnp.min(Q + 1e6 * mask)

    for i in range(len(levels)):
        nQi = critic(transition.next_observation, next_action[i])
        Qi = get_kmin(Q_ensemble[:, i], i)
        tQi = transition.reward + gamma * get_kmin(nQi[:, i], i)
        errs.append(Qi-tQi)
    return jnp.stack(errs)

def flatten_dict(d):
    d_copy = d.copy()
    for k in d:
        if isinstance(d[k], dict):
            dk = flatten_dict(d[k])
            del d_copy[k]
            d_copy.update({f'{k}.{new_k}': v for new_k, v in dk.items()})
    return d_copy


import tqdm
def evaluate(agent: nn.Module, env: gym.Env,
             num_episodes: int, update=False) -> Dict[str, float]:
    stats = defaultdict(list)

    for _ in tqdm.trange(num_episodes):
        agent.reset()
        observation, done = env.reset(), False

        while not done:
            action = agent.sample_actions(observation, temperature=0.0)
            next_observation, r, done, info = env.step(action)
            transition = Transition(observation=observation, action=action, reward=r, next_observation=next_observation)
            if update:
                agent.adapt_transition(transition)
            observation = next_observation
            
        flat_info = flatten_dict(info)
        for k in flat_info:
            stats[k].append(flat_info[k])

    stats = {k: np.mean(v) for k, v in stats.items()}
    print(stats)

    return stats