from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic

def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)

def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    N = critic.model_def.n_ensemble
    levels = critic.model_def.levels
    ic(levels)
    batch_size = len(batch.observations)
    def get_kmin(Q, k):
        mask = jnp.arange(N) > levels[k]
        ic(Q.shape, mask.shape)
        return jnp.min(Q + 1e6 * mask)

    Ks = jax.random.randint(key, shape=(batch_size,), minval=0, maxval=len(levels))
    dist = actor(batch.next_observations)
    next_actions = dist.sample(seed=key)
    next_log_probs = dist.log_prob(next_actions)
    ic(next_actions.shape)
    next_actions = next_actions[Ks, jnp.arange(batch_size)] # Batch_size x NA
    next_log_probs = next_log_probs[Ks, jnp.arange(batch_size)] # Batch_size 
    ic(next_actions.shape, next_log_probs.shape)

    next_q_ensemble = target_critic(batch.next_observations, next_actions) # N x Batch_size x N
    next_q_ensemble = next_q_ensemble[:, jnp.arange(batch_size), Ks]
    ic(next_q_ensemble.shape) # N x Batch_size

    next_q = jax.vmap(get_kmin, in_axes=(1, 0), out_axes=0)(next_q_ensemble, Ks)
    # next_q = jnp.min(next_q_ensemble, 0)
    ic(next_q.shape)

    target_q = batch.rewards + discount * batch.masks * next_q

    if backup_entropy:
        target_q -= discount * batch.masks * temp() * next_log_probs

    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        q_ensemble = critic.apply_fn({'params': critic_params}, batch.observations,
                                 batch.actions)
        q_ensemble = q_ensemble[:, jnp.arange(batch_size), Ks]
        ic(q_ensemble.shape, target_q.shape)
        critic_loss = ((q_ensemble - target_q)**2).mean() #+ (q2 - target_q)**2).mean()
        # critic_loss = jax.vmap(kmin_loss, in_axes=(1, 0, 0), out_axes=1)(q_ensemble, target_q, Ks)
        # ic(critic_loss.shape)
        # critic_loss = critic_loss.mean()
        return critic_loss, {
            'critic_loss': critic_loss,
            'q1': q_ensemble.mean(),
            'target_q': target_q.mean(),
            'next_q_diff': jnp.abs(next_q - jnp.min(next_q_ensemble, 0)).mean(),
            'critic_K_mean': Ks.astype(float).mean(),
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)

    return new_critic, info

# from typing import Tuple

# import jax
# import jax.numpy as jnp

# from jaxrl.datasets import Batch
# from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
# from icecream import ic

# def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
#     new_target_params = jax.tree_multimap(
#         lambda p, tp: p * tau + tp * (1 - tau), critic.params,
#         target_critic.params)

#     return target_critic.replace(params=new_target_params)

# def update(key: PRNGKey, actor: Model, critic: Model, target_critic: Model,
#            temp: Model, batch: Batch, discount: float,
#            backup_entropy: bool) -> Tuple[Model, InfoDict]:
#     levels = critic.model_def.levels
#     batch_size = len(batch.observations)
#     Ks = jax.random.randint(key, shape=(batch_size,), minval=0, maxval=len(levels))
#     dist = actor(batch.next_observations)
#     next_actions = dist.sample(seed=key)
#     next_log_probs = dist.log_prob(next_actions)

#     ic(next_actions.shape)
#     next_actions = next_actions[Ks, jnp.arange(batch_size)] # Batch_size x NA
#     next_log_probs = next_log_probs[Ks, jnp.arange(batch_size)] # Batch_size 
#     ic(next_actions.shape, next_log_probs.shape)

#     next_q_ensemble = target_critic(batch.next_observations, next_actions,
#         method=target_critic.model_def.get_minimum_q) # Batch_size x |Levels|
#     next_q = next_q_ensemble[jnp.arange(batch_size), Ks]
#     ic(next_q_ensemble.shape) # Batch_size x |levels|
#     ic(next_q.shape) # Batch_size

#     target_q = batch.rewards + discount * batch.masks * next_q

#     if backup_entropy:
#         target_q -= discount * batch.masks * temp() * next_log_probs

#     def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
#         q_ensemble = critic.apply_fn({'params': critic_params}, batch.observations,
#                                  batch.actions)
#         q_ensemble = q_ensemble[:, jnp.arange(batch_size), Ks]
#         ic(q_ensemble.shape, target_q.shape)
#         critic_loss = ((q_ensemble - target_q)**2).mean() #+ (q2 - target_q)**2).mean()
#         return critic_loss, {
#             'critic_loss': critic_loss,
#             'q1': q_ensemble.mean(),
#             'target_q': target_q.mean(),
#             'next_q_diff': jnp.abs(next_q - jnp.min(next_q_ensemble, -1)).mean(),
#         }

#     new_critic, info = critic.apply_gradient(critic_loss_fn)

#     return new_critic, info
