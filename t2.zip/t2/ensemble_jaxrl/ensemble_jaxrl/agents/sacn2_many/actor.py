from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic

def update(key: PRNGKey, actor: Model, critic: Model, temp: Model,
           batch: Batch) -> Tuple[Model, InfoDict]:
    N = critic.model_def.n_ensemble
    levels = critic.model_def.levels
    ic(levels)
    batch_size = len(batch.observations)
    Ks = jax.random.randint(key, shape=(batch_size,), minval=0, maxval=len(levels))

    def get_kmin(Q, k):
        mask = jnp.arange(N) > levels[k]
        ic(Q.shape, mask.shape)
        return jnp.min(Q + 1e6 * mask)

    def actor_loss_fn(actor_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        dist = actor.apply_fn({'params': actor_params}, batch.observations)
        actions = dist.sample(seed=key)
        log_probs = dist.log_prob(actions)

        actions = actions[Ks, jnp.arange(batch_size)]
        log_probs = log_probs[Ks, jnp.arange(batch_size)]

        q_ensemble = critic(batch.observations, actions)
        q_ensemble = q_ensemble[:, jnp.arange(batch_size), Ks]
        q = jax.vmap(get_kmin, in_axes=(1, 0), out_axes=0)(q_ensemble, Ks)
        actor_loss = (log_probs * temp() - q).mean()
        return actor_loss, {
            'actor_loss': actor_loss,
            'entropy': -log_probs.mean(),
            'actor_K_mean': Ks.astype(float).mean(),
            'actor_q_diff': jnp.abs(q - jnp.min(q_ensemble, 0)).mean(),
        }

    new_actor, info = actor.apply_gradient(actor_loss_fn)

    return new_actor, info

# from typing import Tuple

# import jax
# import jax.numpy as jnp

# from jaxrl.datasets import Batch
# from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
# from icecream import ic

# def update(key: PRNGKey, actor: Model, critic: Model, temp: Model,
#            batch: Batch) -> Tuple[Model, InfoDict]:
#     levels = critic.model_def.levels
#     batch_size = len(batch.observations)
#     Ks = jax.random.randint(key, shape=(batch_size,), minval=0, maxval=len(levels))

#     def actor_loss_fn(actor_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
#         dist = actor.apply_fn({'params': actor_params}, batch.observations)
#         actions = dist.sample(seed=key)
#         log_probs = dist.log_prob(actions)

#         actions = actions[Ks, jnp.arange(batch_size)]
#         log_probs = log_probs[Ks, jnp.arange(batch_size)]

#         q_ensemble = critic(batch.next_observations, actions,
#             method=critic.model_def.get_minimum_q) # Batch_size x |Levels|
#         q = q_ensemble[jnp.arange(batch_size), Ks]
#         ic(q.shape)
#         # q_ensemble = critic(batch.observations, actions)
#         # q_ensemble = q_ensemble[:, jnp.arange(batch_size), Ks]
#         # # q = jnp.min(q_ensemble, 0)
#         # q = jax.vmap(get_kmin, in_axes=(1, 0), out_axes=0)(q_ensemble, Ks)
#         actor_loss = (log_probs * temp() - q).mean()
#         return actor_loss, {
#             'actor_loss': actor_loss,
#             'entropy': -log_probs.mean(),
#             'actor_q_diff': jnp.abs(q - jnp.min(q_ensemble, 1)).mean(),
#         }

#     new_actor, info = actor.apply_gradient(actor_loss_fn)

#     return new_actor, info
