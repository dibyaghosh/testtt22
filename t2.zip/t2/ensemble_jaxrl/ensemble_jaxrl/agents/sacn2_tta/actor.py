from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from jaxrl.networks.common import InfoDict, Model, Params, PRNGKey


def update(key: PRNGKey, actor: Model, critic: Model, temp: Model,
           batch: Batch) -> Tuple[Model, InfoDict]:
    def actor_loss_fn(actor_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        dist = actor.apply_fn({'params': actor_params}, batch.observations)
        actions = dist.sample(seed=key)
        log_probs = dist.log_prob(actions)
        q_ensemble = critic(batch.observations, actions)
        q = jnp.min(q_ensemble, 0)
        actor_loss = (log_probs * temp() - q).mean()
        return actor_loss, {
            'actor_loss': actor_loss,
            'entropy': -log_probs.mean()
        }

    new_actor, info = actor.apply_gradient(actor_loss_fn)

    return new_actor, info


def mini_update(key: PRNGKey, actor: Model, critic: Model,
           observation) -> Tuple[Model, InfoDict]:
    def actor_loss_fn(actor_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        dist = actor.apply_fn({'params': actor_params}, observation)
        actions = dist.sample(seed=key)
        q_ensemble = critic(observation, actions)
        q = jnp.min(q_ensemble, 0)
        actor_loss =  - 1 * q.mean()
        return actor_loss, {
            'actor_loss': actor_loss,
        }

    new_actor, info = actor.apply_gradient(actor_loss_fn)
    return new_actor, info

@jax.jit
def adapt_update(key: PRNGKey, actor: Model, critic: Model, observation):
    new_actor, first_info = mini_update(key, actor, critic, observation)
    for i in range(10):
        key, rng = jax.random.split(key)
        new_actor, info = mini_update(rng, new_actor, critic, observation)
    return new_actor, first_info['actor_loss'] - info['actor_loss']
