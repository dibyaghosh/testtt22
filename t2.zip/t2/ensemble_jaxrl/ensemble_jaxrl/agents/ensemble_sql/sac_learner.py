"""Implementations of algorithms for continuous control."""

import functools
from typing import Optional, Sequence, Tuple

import jax
import jax.numpy as jnp
import numpy as np
import optax

from ensemble_jaxrl.agents.ensemble_sql import temperature, critic_net
from ensemble_jaxrl.agents.ensemble_sql.actor import update as update_actor
from ensemble_jaxrl.agents.ensemble_sql.critic import target_update
from ensemble_jaxrl.agents.ensemble_sql.critic import update as update_critic
from ensemble_jaxrl.contextual_dataset import EnsembleBatch as Batch
# from jaxrl.datasets import Batch
from jaxrl.networks import policies
from ensemble_jaxrl.networks.common import InfoDict, Model, PRNGKey
from icecream import ic
import flax
@functools.partial(jax.jit,
                   static_argnames=('backup_entropy', 'update_target'))
def _update_jit(
    rng: PRNGKey, actor: Model, critic: Model, target_critic: Model,
    temp: Model, batch: Batch, discount: float, tau: float,
    target_entropy: float, backup_entropy: bool, update_target: bool
) -> Tuple[PRNGKey, Model, Model, Model, Model, InfoDict]:

    rng, key = jax.random.split(rng)
    new_critic, critic_info = update_critic(key,
                                            actor,
                                            critic,
                                            target_critic,
                                            temp,
                                            batch,
                                            discount,
                                            backup_entropy=backup_entropy)
    if update_target:
        new_target_critic = target_update(new_critic, target_critic, tau)
    else:
        new_target_critic = target_critic

    rng, key = jax.random.split(rng)
    new_actor, actor_info = actor, {} #update_actor(key, actor, new_critic, temp, batch)
    new_temp, alpha_info = temp, {'temperature': temp()}
    # new_temp, alpha_info = temperature.update(temp, critic_info['entropy'],
    #                                           target_entropy)

    return rng, new_actor, new_critic, new_target_critic, new_temp, {
        **critic_info,
        **actor_info,
        **alpha_info
    }

@functools.partial(jax.jit,
                   static_argnames=('backup_entropy', 'update_target'))
def _debug_log(
    rng: PRNGKey, actor: Model, critic: Model, target_critic: Model,
    temp: Model, batch: Batch, discount: float, tau: float,
    target_entropy: float, backup_entropy: bool, update_target: bool
):
    info_dict = dict()
    batch_qvals = critic(batch.observations, batch.actions )
    ic(batch_qvals.shape)
    for k, v in dict(batch=batch_qvals).items():
        info_dict[f'{k}_ensemble_mean'] = jnp.mean(v)
        info_dict[f'{k}_ensemble_std'] = jnp.mean(jnp.std(v, axis=0))

    if critic.model_def.has_image:
        norms = critic(batch.observations, method=lambda module, x: module.net.get_cnn(x['observation'], x['descriptor']))
        info_dict[f'cnn_feature_norm'] = jnp.linalg.norm(norms, axis=-1).mean()
        info_dict[f'cnn_feature_norm max'] = jnp.linalg.norm(norms, axis=-1).max()

    return info_dict



class SACLearner(object):
    def __init__(self,
                 seed: int,
                 observations: jnp.ndarray,
                 actions: jnp.ndarray,
                 action_dim: int,
                 n_ensemble: int,
                 actor_lr: float = 3e-4,
                 critic_lr: float = 3e-4,
                 temp_lr: float = 3e-4,
                 hidden_dims: Sequence[int] = (256, 256),
                 discount: float = 0.99,
                 tau: float = 0.005,
                 target_update_period: int = 1,
                 target_entropy: Optional[float] = None,
                 backup_entropy: bool = True,
                 init_temperature: float = 1.0,
                 init_mean: Optional[np.ndarray] = None,
                 policy_final_fc_init_scale: float = 1.0,
                 **kwargs):
        """
        An implementation of the version of Soft-Actor-Critic described in https://arxiv.org/abs/1812.05905
        """
        print('Got extra kwargs: ', kwargs)

        # action_dim = actions.shape[-1]

        if target_entropy is None:
            self.target_entropy = 1.0
        else:
            self.target_entropy = target_entropy

        self.backup_entropy = backup_entropy

        self.tau = tau
        self.target_update_period = target_update_period
        self.discount = discount
        self.n_ensemble = n_ensemble

        rng = jax.random.PRNGKey(seed)
        rng, actor_key, critic_key, temp_key = jax.random.split(rng, 4)
        has_image = 'descriptor' in observations and len(observations['descriptor'].shape) > 2
        ic(has_image)
        # actor_def = critic_net.NormalTanhPolicy(
        #     hidden_dims,
        #     action_dim,
        #     init_mean=init_mean,
        #     final_fc_init_scale=policy_final_fc_init_scale,
        #     has_image=has_image)
        # actor = Model.create(actor_def,
        #                      inputs=[actor_key, observations],
        #                      tx=optax.adam(learning_rate=actor_lr))
        actor = None

        critic_def = critic_net.Critic(action_dim, n_ensemble, hidden_dims, has_image=has_image)
        critic = Model.create(critic_def,
                              inputs=[critic_key, observations, actions],
                              tx=optax.adam(learning_rate=critic_lr))
        target_critic = Model.create(
            critic_def, inputs=[critic_key, observations, actions])

        temp = Model.create(temperature.Temperature(init_temperature),
                            inputs=[temp_key],
                            tx=optax.adam(learning_rate=temp_lr))

        self.actor = actor
        self.critic = critic
        self.target_critic = target_critic
        self.temp = temp
        self.rng = rng

        self.step = 1

    def debug_log(self, batch: Batch) -> InfoDict:
        return _debug_log(
            self.rng, self.actor, self.critic, self.target_critic, self.temp,
            batch, self.discount, self.tau, self.target_entropy,
            self.backup_entropy, self.step % self.target_update_period == 0)

    def sample_actions(self,
                       observations: np.ndarray,
                       weighting: np.ndarray,
                       temperature: float = 1.0,
                       conservative=False) -> jnp.ndarray:
        
        rng, self.rng = jax.random.split(self.rng)
        if conservative:
            actions = critic_net.sample_conservative_actions(rng, self.critic, observations, 0.1, -1)
            return np.asarray(actions)
        else:
            actions = critic_net.sample_actions(rng, self.critic, observations,
                                                0.1)
            actions = np.asarray(actions)
            return np.random.choice(actions, p=weighting)

    def update(self, batch: Batch) -> InfoDict:
        self.step += 1

        new_rng, new_actor, new_critic, new_target_critic, new_temp, info = _update_jit(
            self.rng, self.actor, self.critic, self.target_critic, self.temp,
            batch, self.discount, self.tau, self.target_entropy,
            self.backup_entropy, self.step % self.target_update_period == 0)

        self.rng = new_rng
        self.actor = new_actor
        self.critic = new_critic
        self.target_critic = new_target_critic
        self.temp = new_temp

        return info

    def parameters(self):
        return {
            # 'actor': self.actor,
            'critic': self.critic,
            'temp': self.temp,
        }

    def serialize(self):
        return {
            k: flax.serialization.to_bytes(v.params)
            for k, v in self.parameters().items()
        }
    

    def load(self, d):
        # actor_params = flax.serialization.from_bytes(self.actor.params, d['actor'])
        # self.actor = self.actor.replace(params=actor_params)
        q_params = flax.serialization.from_bytes(self.critic.params, d['critic'])
        self.critic = self.critic.replace(params=q_params)
        self.target_critic = self.target_critic.replace(params=q_params)

        temp_params = flax.serialization.from_bytes(self.temp.params, d['temp'])
        self.temp = self.temp.replace(params=temp_params)


from typing import Dict
from collections import defaultdict



@jax.jit
def get_change(rng, critic, s, c, a, r, ns, gamma):
    ic({k: v.shape for k, v in s.items()}, c.shape, a)
    q = critic(s, method=critic.model_def.get_all_q)[:, a] #critic(s, a)
    nq_ensemble = critic(ns, method=critic.model_def.get_all_q)
    nv = nq_ensemble.max(-1)
    target = r + gamma * nv
    return q, target



def evaluate(agent, env, num_episodes: int, temperature=0.0, adapt=False, conservative=False) -> Dict[str, float]:
    stats = {'return': [], 'length': []}
    stats = defaultdict(list)
    successes = None
    for _ in range(num_episodes):
        observation, done = env.reset(), False
        error = np.zeros(agent.n_ensemble)
        while not done:
            if not isinstance(observation, dict):
                observation = {'observation': observation}
            c = jax.nn.softmax(-1 * error, axis=-1)
            c = np.array(jax.nn.softmax(-1 * error, axis=-1))
            c = c / c.sum()

            action = agent.sample_actions(observation, c, temperature=temperature, conservative=conservative)
            next_observation, r, done, info = env.step(action)
            if not isinstance(next_observation, dict):
                next_observation = {'observation': next_observation}

            if adapt:
                q, target = get_change(agent.rng, agent.critic, observation, c, action, r, next_observation, agent.discount)
                error += jnp.abs(q - target) ** 2

            observation = next_observation

        for k in info:
            if isinstance(info[k], dict):
                continue
            stats[k].append(info[k])
        for k in info['episode']:
            stats[k].append(info['episode'][k])

    for k, v in stats.items():
        stats[k] = np.mean(v)
    print(stats)
    print(c)
    return stats