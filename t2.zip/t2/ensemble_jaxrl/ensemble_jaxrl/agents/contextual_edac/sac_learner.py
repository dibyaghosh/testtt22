"""Implementations of algorithms for continuous control."""

import functools
from typing import Optional, Sequence, Tuple

import jax
import jax.numpy as jnp
import numpy as np
import optax
import flax

from ensemble_jaxrl.agents.contextual_edac import temperature, ensemble_networks
from ensemble_jaxrl.agents.contextual_edac.actor import update as update_actor
from ensemble_jaxrl.agents.contextual_edac.critic import target_update
from ensemble_jaxrl.agents.contextual_edac.critic import update as update_critic
from jaxrl.datasets import Batch
from jaxrl.networks import policies
from ensemble_jaxrl.networks.common import InfoDict, Model, PRNGKey


@functools.partial(jax.jit,
                   static_argnames=('n_ensemble', 'backup_entropy', 'update_target'))
def _update_jit(
    rng: PRNGKey, actor: Model, critic: Model, state_critic: Model, target_critic: Model,
    temp: Model, batch: Batch, discount: float, tau: float,
    target_entropy: float, n_ensemble:int, backup_entropy: bool, update_target: bool
) -> Tuple[PRNGKey, Model, Model, Model, Model, InfoDict]:

    rng, key = jax.random.split(rng)
    new_critic, critic_info = update_critic(key,
                                            actor,
                                            critic,
                                            state_critic,
                                            target_critic,
                                            temp,
                                            batch,
                                            discount,
                                            n_ensemble,
                                            backup_entropy=backup_entropy)
    if update_target:
        new_target_critic = target_update(new_critic, target_critic, tau)
    else:
        new_target_critic = target_critic

    new_actor, new_state_critic, actor_info = update_actor(key, actor, new_critic, state_critic, temp, batch, n_ensemble)
    new_temp, alpha_info = temperature.update(temp, actor_info['entropy'],
                                              target_entropy)

    return rng, new_actor, new_critic, new_state_critic, new_target_critic, new_temp, {
        **critic_info,
        **actor_info,
        **alpha_info
    }

@functools.partial(jax.jit,
                   static_argnames=('n_ensemble', 'backup_entropy', 'update_target'))
def _debug_log(
    rng: PRNGKey, actor: Model, critic: Model, state_critic: Model, target_critic: Model,
    temp: Model, batch: Batch, discount: float, tau: float,
    target_entropy: float, n_ensemble:int, backup_entropy: bool, update_target: bool
):
    contexts = ensemble_networks.sample_context(rng, n_ensemble, (len(batch.actions),))
    _, actions = policies.sample_actions(rng, actor.apply_fn,
                                            actor.params, batch.observations, contexts,
                                            1.0)

    info_dict = dict()
    batch_qvals = critic(batch.observations, contexts, batch.actions )
    pi_qvals = critic(batch.observations, contexts, actions)

    for k, v in dict(batch=batch_qvals, pi=pi_qvals).items():
        info_dict[f'{k}_ensemble_mean'] = jnp.mean(v)
        info_dict[f'{k}_ensemble_std'] = jnp.mean(jnp.std(v, axis=1))

    return info_dict

class SACLearner(object):
    def __init__(self,
                 seed: int,
                 observations: jnp.ndarray,
                 actions: jnp.ndarray,
                 n_ensemble: int,
                 actor_lr: float = 3e-4,
                 critic_lr: float = 3e-4,
                 temp_lr: float = 3e-4,
                 hidden_dims: Sequence[int] = (256, 256),
                 discount: float = 0.99,
                 tau: float = 0.005,
                 target_update_period: int = 1,
                 target_entropy: Optional[float] = None,
                 backup_entropy: bool = True,
                 init_temperature: float = 1.0,
                 init_mean: Optional[np.ndarray] = None,
                 policy_final_fc_init_scale: float = 1.0,
                 **kwargs):
        """
        An implementation of the version of Soft-Actor-Critic described in https://arxiv.org/abs/1812.05905
        """
        print('Got extra arguments: ', kwargs)
        self.n_ensemble = n_ensemble
        action_dim = actions.shape[-1]

        if target_entropy is None:
            self.target_entropy = -action_dim / 2
        else:
            self.target_entropy = target_entropy

        self.backup_entropy = backup_entropy

        self.tau = tau
        self.target_update_period = target_update_period
        self.discount = discount

        rng = jax.random.PRNGKey(seed)
        rng, actor_key, critic_key, temp_key = jax.random.split(rng, 4)
        has_image = 'descriptor' in observations and len(observations['descriptor'].shape) > 2

        contexts = ensemble_networks.sample_context(rng, self.n_ensemble, (len(actions),))
        actor_def = ensemble_networks.NormalTanhPolicy(
            hidden_dims,
            action_dim,
            init_mean=init_mean,
            final_fc_init_scale=policy_final_fc_init_scale,
            has_image=has_image)

        actor = Model.create(actor_def,
                             inputs=[actor_key, observations, contexts],
                             tx=optax.adam(learning_rate=actor_lr))

        critic_def = ensemble_networks.Critic(hidden_dims, self.n_ensemble, has_image=has_image)
        critic = Model.create(critic_def,
                              inputs=[critic_key, observations, contexts, actions],
                              tx=optax.adam(learning_rate=critic_lr))

        target_critic = Model.create(
            critic_def, inputs=[critic_key, observations, contexts, actions])

        state_critic_def = ensemble_networks.StateCritic(hidden_dims, self.n_ensemble, has_image=has_image)
        state_critic = Model.create(state_critic_def,
                              inputs=[critic_key, observations, contexts],
                              tx=optax.adam(learning_rate=critic_lr))

        temp = Model.create(temperature.Temperature(init_temperature),
                            inputs=[temp_key],
                            tx=optax.adam(learning_rate=temp_lr))

        self.actor = actor
        self.critic = critic
        self.state_critic = state_critic
        self.target_critic = target_critic
        self.temp = temp
        self.rng = rng

        self.step = 1

    def sample_actions(self,
                       observations: np.ndarray,
                       contexts: np.ndarray,
                       temperature: float = 1.0) -> jnp.ndarray:
        rng, actions = policies.sample_actions(self.rng, self.actor.apply_fn,
                                               self.actor.params, observations,
                                               contexts,
                                               temperature)
        self.rng = rng

        actions = np.asarray(actions)
        return np.clip(actions, -1, 1)

    def debug_log(self, batch: Batch) -> InfoDict:
        return _debug_log(
            self.rng, self.actor, self.critic, self.state_critic, self.target_critic, self.temp,
            batch, self.discount, self.tau, self.target_entropy, self.n_ensemble,
            self.backup_entropy, self.step % self.target_update_period == 0)

    def update(self, batch: Batch) -> InfoDict:
        self.step += 1

        new_rng, new_actor, new_critic, new_state_critic, new_target_critic, new_temp, info = _update_jit(
            self.rng, self.actor, self.critic, self.state_critic, self.target_critic, self.temp,
            batch, self.discount, self.tau, self.target_entropy, self.n_ensemble,
            self.backup_entropy, self.step % self.target_update_period == 0)

        self.rng = new_rng
        self.actor = new_actor
        self.critic = new_critic
        self.state_critic = new_state_critic
        self.target_critic = new_target_critic
        self.temp = new_temp

        return info


    def parameters(self):
        return {
            'actor': self.actor,
            'critic': self.critic,
            'state_critic': self.state_critic,
            'temp': self.temp,
        }

    def serialize(self):
        return {
            k: flax.serialization.to_bytes(v.params)
            for k, v in self.parameters().items()
        }
    

    def load(self, d):
        actor_params = flax.serialization.from_bytes(self.actor.params, d['actor'])
        self.actor = self.actor.replace(params=actor_params)
        q_params = flax.serialization.from_bytes(self.critic.params, d['critic'])
        self.critic = self.critic.replace(params=q_params)
        self.target_critic = self.target_critic.replace(params=q_params)

        v_params = flax.serialization.from_bytes(self.state_critic.params, d['state_critic'])
        self.state_critic = self.state_critic.replace(params=v_params)

        temp_params = flax.serialization.from_bytes(self.temp.params, d['temp'])
        self.temp = self.temp.replace(params=temp_params)


from typing import Dict

import flax.linen as nn
import gym
import numpy as np
from collections import defaultdict
from icecream import ic

@jax.jit
def update_context(context, critic, state_critic, s, a, ns, r, discount):
    curr_pred = critic(s, context, a)
    next_pred = r + discount * state_critic(ns, context)
    error = jnp.abs(next_pred - curr_pred)
    new_context = ensemble_networks.update_context(context, error)  
    return new_context, error

def evaluate(agent, env: gym.Env, num_episodes: int, temperature=0.0) -> Dict[str, float]:
    stats = {'return': [], 'length': []}
    stats = defaultdict(list)
    successes = None
    for _ in range(num_episodes):
        observation, done = env.reset(), False
        context = jnp.ones(agent.n_ensemble) / agent.n_ensemble
        while not done:
            if not isinstance(observation, dict):
                observation = {'observation': observation}
            action = agent.sample_actions(observation, context, temperature=temperature)
            new_observation, r, done, info = env.step(action)
            if not isinstance(new_observation, dict):
                new_observation = {'observation': new_observation}
            context, error = update_context(context, agent.critic, agent.state_critic, observation, action, new_observation, r, agent.discount)
            observation = new_observation
            # next_pred = r + agent.discount * agent.state_critic(observation, context)
            # error = jnp.abs(next_pred - curr_pred)
            # context = ensemble_networks.update_context(context, error)


        for k in info:
            if isinstance(info[k], dict):
                continue
            stats[k].append(info[k])
        for k in info['episode']:
            stats[k].append(info['episode'][k])
        print(info)
        print(context)
        print(ensemble_networks.sample_context(agent.rng, agent.n_ensemble, (1,)))

    for k, v in stats.items():
        stats[k] = np.mean(v)
    return stats