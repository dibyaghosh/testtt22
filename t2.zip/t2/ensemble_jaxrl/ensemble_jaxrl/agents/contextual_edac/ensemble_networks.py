
from typing import Callable, Sequence, Tuple, Optional

import jax
import jax.numpy as jnp
from flax import linen as nn

from jaxrl.networks.common import MLP, default_init
from collections import OrderedDict

class CNNHead(nn.Module):
  @nn.compact
  def __call__(self, x):
    x = jnp.moveaxis(x, -3, -1)
    x = x.reshape((*x.shape[:-3], -1))
    return nn.Dense(4)(x)
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = nn.Conv(features=32, kernel_size=(3, 3))(x)
    x = nn.relu(x)
    x = nn.avg_pool(x, window_shape=(2, 2), strides=(2, 2))
    x = x.reshape((*x.shape[:-3], -1))
    return jax.lax.stop_gradient(x)
    x = nn.Dense(4)(x)
    return x #jnp.zeros_like(jax.lax.stop_gradient(x))  # flatten

class MLPWithImage(nn.Module):
    hidden_dims: Sequence[int]
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    activate_final: int = False
    dropout_rate: Optional[float] = None
    has_image: bool = False

    def setup(self):
        if self.has_image:
            self.cnn = CNNHead()
        self.mlp = MLP(self.hidden_dims, self.activations, self.activate_final, self.dropout_rate)
        
    def __call__(self, x, image=None, training=True):
        if self.has_image:
            z = self.cnn(image)
            self.sow('intermediates', 'cnn_features', z)
            print(z.shape, x.shape)
            x = jnp.concatenate([x, z], -1)
        return self.mlp(x, training=training)
        
class EnsembleMLP(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    independent: bool = True
    has_image: bool = False

    def setup(self):
        VmapMLP = nn.vmap(MLPWithImage, variable_axes={'params': 0}, split_rngs={'params': True}, in_axes=None, out_axes=-1, axis_size=self.n_ensemble)
        self.net = VmapMLP((*self.hidden_dims, 1), activations=self.activations, has_image=self.has_image)
    
    @nn.compact
    def __call__(self, xs, images=None):
        if self.independent:
            y = self.net(xs, images)
            y = jnp.squeeze(y, -2)
            return y
        else:
            raise NotImplementedError()
            mlp = MLP((*self.hidden_dims, self.n_ensemble), activations=self.activations)(xs)
            return mlp

class StateCritic(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    independent: bool = True
    has_image: bool = False

    def setup(self):
        self.net = EnsembleMLP(self.hidden_dims, self.n_ensemble,
                     activations=self.activations, independent=self.independent, has_image=self.has_image)

    def __call__(self, observations, contexts) -> jnp.ndarray:
        inputs = jnp.concatenate([observations['observation'], contexts], -1)
        images = observations['descriptor'] if self.has_image else None
        return self.net(inputs, images)

class Critic(nn.Module):
    hidden_dims: Sequence[int]
    n_ensemble: int
    activations: Callable[[jnp.ndarray], jnp.ndarray] = nn.relu
    independent: bool = True
    has_image: bool = False

    def setup(self):
        self.net = EnsembleMLP(self.hidden_dims, self.n_ensemble,
                     activations=self.activations, independent=self.independent, has_image=self.has_image)

    def __call__(self, observations: jnp.ndarray, contexts: jnp.ndarray,
                 actions: jnp.ndarray) -> jnp.ndarray:
        inputs = jnp.concatenate([observations['observation'], contexts, actions], -1)
        images = observations['descriptor'] if self.has_image else None
        return self.net(inputs, images)

from jaxrl.networks import policies
from tensorflow_probability.substrates import jax as tfp

tfd = tfp.distributions
tfb = tfp.bijectors

class NormalTanhPolicy(nn.Module):
    hidden_dims: Sequence[int]
    action_dim: int
    state_dependent_std: bool = True
    dropout_rate: Optional[float] = None
    final_fc_init_scale: float = 1.0
    log_std_min: Optional[float] = None
    log_std_max: Optional[float] = None
    tanh_squash_distribution: bool = True
    init_mean: Optional[jnp.ndarray] = None
    has_image: bool = False

    @nn.compact
    def __call__(self,
                 observations: jnp.ndarray,
                 contexts: jnp.ndarray,
                 temperature: float = 1.0,
                 training: bool = False) -> tfd.Distribution:
        inputs = jnp.concatenate([observations['observation'], contexts], -1)
        images = observations['descriptor'] if self.has_image else None
        outputs = MLPWithImage(self.hidden_dims,
                      activate_final=True,
                      dropout_rate=self.dropout_rate, has_image=self.has_image)(inputs, images,
                                                      training=training)

        means = nn.Dense(self.action_dim,
                         kernel_init=default_init(
                             self.final_fc_init_scale))(outputs)
        if self.init_mean is not None:
            means += self.init_mean

        if self.state_dependent_std:
            log_stds = nn.Dense(self.action_dim,
                                kernel_init=default_init(
                                    self.final_fc_init_scale))(outputs)
        else:
            log_stds = self.param('log_stds', nn.initializers.zeros,
                                  (self.action_dim, ))

        log_std_min = self.log_std_min or policies.LOG_STD_MIN
        log_std_max = self.log_std_max or policies.LOG_STD_MAX
        log_stds = jnp.clip(log_stds, log_std_min, log_std_max)

        if not self.tanh_squash_distribution:
            means = nn.tanh(means)

        base_dist = tfd.MultivariateNormalDiag(loc=means,
                                               scale_diag=jnp.exp(log_stds) *
                                               temperature)
        if self.tanh_squash_distribution:
            return tfd.TransformedDistribution(distribution=base_dist,
                                               bijector=tfb.Tanh())
        else:
            return base_dist

def sample_context(key, n_ensemble, shape):
    # return jnp.ones((*shape, n_ensemble)) / n_ensemble
    return jax.random.dirichlet(key, jnp.ones(n_ensemble) * 0.1, shape=shape)

def update_context(c, error):
    # return c
    new_contexts = jax.nn.softmax(jnp.log(c) * 0.95 - jnp.abs(error), axis=-1)
    new_contexts = jnp.clip(new_contexts, 0.001, 1)
    new_contexts = new_contexts / new_contexts.sum(-1, keepdims=True)
    return new_contexts

import functools
from typing import Any, Callable, Optional, Sequence, Tuple
from jaxrl.networks.common import MLP, Params, PRNGKey, default_init
import numpy as np

@functools.partial(jax.jit, static_argnames=('actor_apply_fn', 'distribution'))
def _sample_actions(
        rng: PRNGKey,
        actor_apply_fn: Callable[..., Any],
        actor_params: Params,
        observations: np.ndarray,
        contexts: np.ndarray,
        temperature: float = 1.0,
        distribution: str = 'log_prob') -> Tuple[PRNGKey, jnp.ndarray]:
    if distribution == 'det':
        return rng, actor_apply_fn({'params': actor_params}, observations, contexts,
                                   temperature)
    else:
        dist = actor_apply_fn({'params': actor_params}, observations, contexts,
                              temperature)
        rng, key = jax.random.split(rng)
        return rng, dist.sample(seed=key)


def sample_actions(
        rng: PRNGKey,
        actor_apply_fn: Callable[..., Any],
        actor_params: Params,
        observations: np.ndarray,
        contexts: np.ndarray,
        temperature: float = 1.0,
        distribution: str = 'log_prob') -> Tuple[PRNGKey, jnp.ndarray]:
    return _sample_actions(rng, actor_apply_fn, actor_params, observations, contexts,
                           temperature, distribution)
