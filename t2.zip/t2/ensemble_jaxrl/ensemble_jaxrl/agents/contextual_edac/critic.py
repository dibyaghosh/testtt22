from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from ensemble_jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from icecream import ic
import functools as ft
from ensemble_jaxrl.agents.contextual_edac import ensemble_networks


def target_update(critic: Model, target_critic: Model, tau: float) -> Model:
    new_target_params = jax.tree_multimap(
        lambda p, tp: p * tau + tp * (1 - tau), critic.params,
        target_critic.params)

    return target_critic.replace(params=new_target_params)


def update(key: PRNGKey, actor: Model, critic: Model, state_critic: Model, target_critic: Model,
           temp: Model, batch: Batch, discount: float, n_ensemble: int,
           backup_entropy: bool) -> Tuple[Model, InfoDict]:
    key, rng = jax.random.split(key, 2)
    contexts = ensemble_networks.sample_context(rng, n_ensemble, (len(batch.actions),))
    curr_pred = critic(batch.observations, contexts, batch.actions)
    ic(state_critic(batch.next_observations, contexts))
    next_pred = batch.rewards[..., None] + discount * batch.masks[..., None] * state_critic(batch.next_observations, contexts)
    error = jnp.abs(curr_pred - next_pred)
    next_contexts = ensemble_networks.update_context(contexts, error)

    dist = actor(batch.next_observations, next_contexts)
    next_actions = dist.sample(seed=key)
    next_log_probs = dist.log_prob(next_actions)
    next_q_ensemble = target_critic(batch.next_observations, next_contexts, next_actions)
    next_q = next_q_ensemble
    # next_q = jnp.min(next_q_ensemble, axis=-1)[..., None]
    
    target_q = batch.rewards[..., None] + discount * batch.masks[..., None] * next_q
    if backup_entropy:
        target_q -= (discount * batch.masks * temp() * next_log_probs)[..., None]
    ic(next_q.shape, target_q.shape)
 
    def critic_loss_fn(critic_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        q_ensemble = critic.apply_fn({'params': critic_params}, batch.observations, contexts,
                                 batch.actions)
        ic(q_ensemble.shape, target_q.shape)
        critic_loss = ((q_ensemble - target_q)**2).mean()
        ic(((q_ensemble - target_q)**2).shape)
        grad_loss = 0

        return critic_loss + grad_loss, {
            'critic_loss': critic_loss,
            'q1': q_ensemble.mean(),
            'grad_loss': grad_loss,
        }

    new_critic, info = critic.apply_gradient(critic_loss_fn)

    return new_critic, info
