from typing import Tuple

import jax
import jax.numpy as jnp

from jaxrl.datasets import Batch
from ensemble_jaxrl.networks.common import InfoDict, Model, Params, PRNGKey
from ensemble_jaxrl.agents.contextual_edac import ensemble_networks

from icecream import ic

def update(key: PRNGKey, actor: Model, critic: Model, state_critic: Model, temp: Model,
           batch: Batch, n_ensemble: int) -> Tuple[Model, InfoDict]:
    key, rng = jax.random.split(key, 2)
    contexts = ensemble_networks.sample_context(rng, n_ensemble, (len(batch.actions),))

    def actor_loss_fn(actor_params: Params) -> Tuple[jnp.ndarray, InfoDict]:
        print(contexts.shape)
        dist = actor.apply_fn({'params': actor_params}, batch.observations, contexts)
        actions = dist.sample(seed=key)
        log_probs = dist.log_prob(actions)
        ensemble_q = critic(batch.observations, contexts, actions)
        q = jnp.sum(contexts * ensemble_q, axis=-1)

        actor_loss = (log_probs * temp() - q).mean()
        return actor_loss, {
            'q_pi_actor': ensemble_q.mean(),
            'actor_loss': actor_loss,
            'entropy': -log_probs.mean()
        }
    
    def state_critic_loss_fn(state_critic_params: Params):
        dist = actor(batch.observations, contexts)
        actions = dist.sample(seed=key)
        log_probs = dist.log_prob(actions)
        ensemble_q = critic(batch.observations, contexts, actions)
        target_v = ensemble_q 
        target_v -= temp() * log_probs[..., None]
        v_ensemble = state_critic.apply_fn({'params': state_critic_params}, batch.observations,
                                 contexts)
        ic(target_v.shape, v_ensemble.shape)                        
        critic_loss = ((v_ensemble - target_v)**2).mean()
        return critic_loss, {
            'state_critic_loss': critic_loss,
        }


    new_actor, actor_info = actor.apply_gradient(actor_loss_fn)
    new_state_critic, state_critic_info = state_critic.apply_gradient(state_critic_loss_fn)

    return new_actor, new_state_critic, {**actor_info, **state_critic_info}
