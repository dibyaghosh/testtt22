import collections
from typing import Tuple, Union

import numpy as np
from tqdm import tqdm

Batch = collections.namedtuple(
    'Batch',
    ['observations', 'actions', 'rewards', 'masks', 'next_observations'])

EnsembleBatch = collections.namedtuple(
    'Batch',
    ['observations', 'actions', 'rewards', 'masks', 'next_observations', 'ensemble_masks'])



class DatasetWrapper:
    def __init__(self, dataset):
        self.dataset = dataset
    
    def sample(self, batch_size):
        batch = self.dataset.sample(batch_size)
        return Batch(
            observations={'observation': batch.observations},
            actions=batch.actions,
            rewards=batch.rewards,
            masks=batch.masks,
            next_observations={'observation': batch.next_observations},
        )        

class DictDataset(object):
    def __init__(self, observations: dict, actions: np.ndarray,
                 rewards: np.ndarray, masks: np.ndarray,
                 dones_float: np.ndarray, next_observations: dict,
                 ensemble_masks: np.ndarray,
                 size: int, bootstrap=False):

        self.observations = observations
        self.actions = actions
        self.rewards = rewards
        self.masks = masks
        self.dones_float = dones_float
        self.next_observations = next_observations
        self.ensemble_masks = ensemble_masks
        self.size = size
        self.bootstrap = bootstrap
        

    def sample(self, batch_size: int) -> Batch:
        indx = np.random.randint(self.size, size=batch_size)
        if self.bootstrap:
            return EnsembleBatch(observations={k: v[indx] for k, v in self.observations.items()},
                        actions=self.actions[indx],
                        rewards=self.rewards[indx],
                        masks=self.masks[indx],
                        next_observations={k: v[indx] for k, v in self.next_observations.items()},
                        ensemble_masks=self.ensemble_masks[indx])

        else:
            return Batch(observations={k: v[indx] for k, v in self.observations.items()},
                        actions=self.actions[indx],
                        rewards=self.rewards[indx],
                        masks=self.masks[indx],
                        next_observations={k: v[indx] for k, v in self.next_observations.items()})
                     
    #self.next_observations[indx])
class RoomWorldDataset(DictDataset):
    def __init__(self, env, bootstrap=False):
        dataset = env.dict_dataset()
        if 'ensemble_masks' not in dataset:
            dataset['ensemble_masks'] = np.ones((len(dataset['actions']), 100))

        super().__init__(dataset['observations'],
                         actions=dataset['actions'],
                         rewards=dataset['rewards'].astype(np.float32),
                         masks=1.0 - dataset['terminals'].astype(np.float32),
                         dones_float=dataset['terminals'].astype(np.float32),
                         next_observations=dataset['next_observations'],
                         ensemble_masks=dataset['ensemble_masks'].astype(np.float32),
                         size=len(dataset['actions']),
                         bootstrap=bootstrap)

from jaxrl.utils import make_env
def make_dictenv_and_dataset(env_name: str, seed: int, dataset_name: str,
                         video_save_folder: str, bootstrap=False):
    env = make_env(env_name, seed, video_save_folder, flatten=False)
    dataset = RoomWorldDataset(env, bootstrap)
    return env, dataset
