import wandb
from ml_collections import ConfigDict
from ml_collections.config_flags import config_flags

import random
import pprint
import time
import uuid
import tempfile
import os
from copy import copy
from socket import gethostname
import os.path as osp
import numpy as np

import absl.flags as flags
from ml_collections import ConfigDict
from ml_collections.config_flags import config_flags
import datetime
import wandb

flags.DEFINE_boolean('wandb_offline', False, 'is WandB online?')

class WandBLogger(object):

    @staticmethod
    def get_default_config():
        config = ConfigDict()
        config.online = not flags.FLAGS.wandb_offline
        config.project = 'jaxrl'
        config.output_dir = '/tmp/SimpleSAC'
        config.random_delay = 0.0
        config.experiment_id = ''
        config.tags = []
        return config
    
    def __init__(self, config, variant, exp_prefix='', exp_descriptor='', unique_identifier=None):
        self.config = WandBLogger.get_default_config()
        self.config.update(config)
        if not unique_identifier:
            unique_identifier = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.config.experiment_id = f'{exp_prefix}_{exp_descriptor}_{unique_identifier}'

        if self.config.output_dir == '':
            self.config.output_dir = tempfile.mkdtemp()
        else:
            self.config.output_dir = os.path.join(self.config.output_dir, self.config.experiment_id)
            os.makedirs(self.config.output_dir, exist_ok=True)

        self._variant = copy(variant)

        if 'hostname' not in self._variant:
            self._variant['hostname'] = gethostname()

        if self.config.random_delay > 0:
            time.sleep(np.random.uniform(0, self.config.random_delay))

        run = wandb.init(
            config=self._variant,
            project=self.config.project,
            tags=[exp_prefix],
            group=exp_prefix,
            dir=self.config.output_dir,
            id=self.config.experiment_id,
            settings=wandb.Settings(
                start_method="thread",
                _disable_stats=True,
            ),
            mode='online' if self.config.online else 'offline',
            save_code=True,
        )
        wandb.config.update(flags.FLAGS)
        print('Saving all code from: ', osp.abspath(osp.dirname(__file__)))
        run.log_code(root=osp.abspath(osp.dirname(__file__)))

    def log(self, *args, **kwargs):
        wandb.log(*args, **kwargs)

    def save_pickle(self, obj, filename):
        with open(os.path.join(self.config.output_dir, filename), 'wb') as fout:
            pickle.dump(obj, fout)

    @property
    def online(self):
        return self.config.online

    @property
    def project(self):
        return self.config.project

    @property
    def experiment_id(self):
        return self.config.experiment_id

    @property
    def variant(self):
        return self.config.variant

    @property
    def output_dir(self):
        return self.config.output_dir
